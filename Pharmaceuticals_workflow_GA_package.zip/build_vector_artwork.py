from pathlib import Path
import math,json,zipfile
from xml.sax.saxutils import escape
import numpy as np
from pptx import Presentation
from pptx.util import Inches,Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN
from pptx.enum.dml import MSO_LINE_DASH_STYLE
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from fontTools.ttLib import TTFont as FT
import fitz
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
O=Path(__file__).resolve().parent;W,H=2200,1120
N='#17364E';T='#07867F';P='#80529D';G='#B98426';GRAY='#647585';BORDER='#C9D5DE';RED='#D74646'
regular='/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf';bold='/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf';cmap=FT(regular).getBestCmap();scene=[]
def rect(x,y,w,h,fill='white',stroke=None,r=12,name='panel'):scene.append(dict(kind='rect',x=x,y=y,w=w,h=h,fill=fill,stroke=stroke,r=r,name=name))
def ell(x,y,r,fill,name='atom'):scene.append(dict(kind='ellipse',x=x-r,y=y-r,w=r*2,h=r*2,fill=fill,name=name))
def text(x,y,t,size=28,col=N,bold=False,align='start',name='text'):
 assert size>=24
 scene.append(dict(kind='text',x=x,y=y,t=t,size=size,col=col,bold=bold,align=align,font='DejaVu Sans' if any(ord(ch) not in cmap for ch in t) else 'Arial',name=name))
def poly(pts,fill=None,col=N,width=2,closed=False,dash=False,name='path'):scene.append(dict(kind='path',pts=[tuple(map(float,p)) for p in pts],col=col,width=width,dash=dash,fill=fill,closed=closed,name=name))
def line(x1,y1,x2,y2,col=N,width=2,dash=False,name='line'):poly([(x1,y1),(x2,y2)],col=col,width=width,dash=dash,name=name)
def arrow(x1,y1,x2,y2,col=N,width=3,head=10,dash=False,name='arrow'):
 dx=x2-x1;dy=y2-y1;l=math.hypot(dx,dy);ux,uy=dx/l,dy/l;bx,by=x2-ux*head,y2-uy*head;line(x1,y1,bx,by,col,width,dash,name+'_shaft');poly([(x2,y2),(bx-uy*head*.58,by+ux*head*.58),(bx+uy*head*.58,by-ux*head*.58)],col,col,0,True,name=name+'_head')
def sphere(x,y,rad,col,name='atom'):
 ell(x,y,rad,col,name);ell(x-rad*.20,y-rad*.22,rad*.62,{'#596574':'#73818E',RED:'#E96666','#F1F3F6':'#FFFFFF'}.get(col,'#9BC4C3'),name+'_light');ell(x-rad*.36,y-rad*.37,rad*.19,'#E8EFF1',name+'_highlight')
models=json.loads((O/'diarylmethanol_conformers.json').read_text())['conformers']
def molecule(index,x,y,ww,hh,show_torsion=False):
 conf=models[index];atoms=conf['atoms'];xyz=np.array([a['p'] for a in atoms]);uv=xyz[:,:2];mins=uv.min(axis=0);span=np.maximum(uv.max(axis=0)-mins,1e-6);scale=min((ww-30)/span[0],(hh-30)/span[1]);xy=(uv-(mins+span/2))*scale+np.array([x+ww/2,y+hh/2]);xy[:,1]=2*(y+hh/2)-xy[:,1];lookup={a['i']:(p,a) for a,p in zip(atoms,xy)}
 # Each bond is split at its midpoint, preserving atom connectivity and C=O bond order.
 for b in conf['bonds']:
  pa,aa=lookup[b['i']];pb,ab=lookup[b['j']];dv=pb-pa;dd=np.linalg.norm(dv);normal=np.array([-dv[1],dv[0]])/dd
  shifts=[-2.7,2.7] if b['order']==2 else [0]
  for sh in shifts:
   u,v=pa+normal*sh,pb+normal*sh;mid=(u+v)/2;line(*u,*mid,RED if aa['symbol']=='O' else '#6F7C88',3.1,name='diarylmethanol_bond');line(*mid,*v,RED if ab['symbol']=='O' else '#6F7C88',3.1,name='diarylmethanol_bond')
 for k in np.argsort(xyz[:,2]):
  a=atoms[int(k)];xx,yy=xy[int(k)];rad=5.4 if a['symbol']=='H' else 8.7 if a['symbol']=='O' else 7.8;sphere(xx,yy,rad,RED if a['symbol']=='O' else '#F1F3F6' if a['symbol']=='H' else '#596574','diarylmethanol_'+a['symbol'])
  if a['chiral']:text(xx+11,yy-7,'*',24,G,True,name='stereogenic_center_marker')
 if show_torsion:
  # One actual rotatable C-C bond is highlighted; the arc is a torsion-sampling symbol.
  bs=[b for b in conf['bonds'] if b['order']==1 and all(lookup[i][1]['symbol']=='C' for i in [b['i'],b['j']])];b=bs[len(bs)//2];pa=lookup[b['i']][0];pb=lookup[b['j']][0];mid=(pa+pb)/2
  ang=np.linspace(-.7,3.8,35);pts=[(mid[0]+18*np.cos(a),mid[1]+18*np.sin(a)) for a in ang];poly(pts,col=G,width=2.5,name='torsional_scan_arc');arrow(*pts[-3],*pts[-1],G,2.5,6,name='torsional_scan_arrow')
 return lookup
# Schematic spectra: sticks transformed to continuous curves; not molecular calculation outputs.
def spectrum(x,y,ww,hh,col,mode='ecd',compare=False,name='spectrum'):
 line(x,y+hh/2,x+ww,y+hh/2,'#9AAAB6',1.3,name=name+'_zero');line(x,y,x,y+hh,'#9AAAB6',1.3,name=name+'_axis')
 centers=[.19,.39,.66,.83] if mode=='ecd' else [.12,.26,.34,.45,.55,.68,.76,.88];strength=[.9,-.62,.55,-.3] if mode=='ecd' else [.65,-.85,.7,-.42,.8,-.55,.45,-.6];sigma=.06 if mode=='ecd' else .017
 def f(u,shift=0):
  if mode=='ecd':return sum(a*math.exp(-((u-m+shift)/sigma)**2) for a,m in zip(strength,centers))
  return sum(a/(1+((u-m+shift)/sigma)**2) for a,m in zip(strength,centers))
 pts=[(x+ww*i/150,y+hh/2-hh*.36*f(i/150)) for i in range(151)];poly(pts,col=col,width=3.1,name=name+'_weighted')
 if compare:poly([(x+ww*i/150,y+hh/2-hh*.33*f(i/150,.022)) for i in range(151)],col=GRAY,width=2,dash=True,name=name+'_experimental_schematic')
def sticks(x,y,ww,hh,col,mode):
 centers=[.12,.35,.56,.82] if mode=='ecd' else [.1,.2,.32,.44,.52,.66,.75,.88];a=[.75,-.6,.95,-.45] if mode=='ecd' else [.65,-.8,.55,-.45,.9,-.7,.4,-.6];line(x,y+hh/2,x+ww,y+hh/2,'#9AAAB6',1.2)
 for p,v in zip(centers,a):line(x+p*ww,y+hh/2,x+p*ww,y+hh/2-v*hh*.44,col,3,name=mode+'_rotatory_strength_stick')
# Original pictorial workflow: methods are connected, not a single-case data narrative.
text(1100,63,'From conformational ensembles to ECD/VCD interpretation',44,N,True,'middle','title')
text(1100,108,'Quantum-chemical methods • ensemble averaging • stereochemical insight',28,GRAY,False,'middle')
xs=[60,482,904,1326,1748];bw=392
heads=['Sample','Refine','Populate','Calculate','Compare']
for i,x in enumerate(xs):
 rect(x,190,bw,587,'#FCF8EF' if i==2 else '#F6F9FB',None,18,'method_panel_'+str(i+1))
 ell(x+34,156,24,T if i!=2 else G,'step_number_badge');text(x+34,165,str(i+1),27,'white',True,'middle')
 text(x+78,168,heads[i],35,N,True,name='step_'+str(i+1)+'_label')
 if i<4:arrow(x+bw+3,451,xs[i+1]-5,451,N,3,10,name='method_connection_'+str(i+1))
# Sampling: representative stereochemically consistent models, not a named case.
x=xs[0]
for i in range(3):molecule(i,x+7+i*125,218,128,129,show_torsion=i==1)
text(x+bw/2,385,'Conformer ensemble',28,N,True,'middle')
# Two-torsion potential surface, drawn as geometric paths.
px,py,pw,ph=x+56,431,287,201
xx=np.linspace(-3.2,3.2,90);yy=np.linspace(-3.2,3.2,75);X,Y=np.meshgrid(xx,yy)
Z=1.3+.11*(X*X+Y*Y)-1.45*np.exp(-((X+1.2)**2+(Y+.8)**2)/.9)-1.2*np.exp(-((X-1.1)**2+(Y-1.2)**2)/.7)-.8*np.exp(-((X-1.4)**2+(Y+1.3)**2)/.5)
fig,ax=plt.subplots();co=ax.contour(X,Y,Z,levels=np.linspace(Z.min()+.1,Z.max()-.2,10));cols=['#9AD2CC','#72BFB5','#42A59A','#198A7F']
for lev,seglist in enumerate(co.allsegs):
 for seg in seglist:poly([(px+(u+3.2)/6.4*pw,py+(3.2-v)/6.4*ph) for u,v in seg],col=cols[lev%4],width=1.5,name='schematic_energy_contour')
plt.close(fig);line(px,py,px,py+ph,GRAY,1.3);line(px,py+ph,px+pw,py+ph,GRAY,1.3)
for u,v in [(-1.2,-.8),(1.1,1.2),(1.4,-1.3)]:ell(px+(u+3.2)/6.4*pw,py+(3.2-v)/6.4*ph,5,G)
text(px-29,py+106,'φ₂',25,GRAY,False,'middle');text(px+pw/2,py+ph+32,'φ₁',25,GRAY,False,'middle')
text(x+bw/2,704,'Explore the energy landscape',25,T,True,'middle');text(x+bw/2,747,'CREST • MC • MD',25,GRAY,False,'middle')
# Geometry refinement: representative structure, displacement arrows and a stationary minimum.
x=xs[1];lookup=molecule(0,x+26,218,bw-52,173)
for k in [1,6,8]:
 p,a=lookup[k];dx=p[0]-(x+bw/2);dy=p[1]-300;nn=math.hypot(dx,dy) or 1
 arrow(p[0]+dx/nn*9,p[1]+dy/nn*9,p[0]+dx/nn*40,p[1]+dy/nn*40,T,2.5,7,name='illustrative_vibrational_displacement')
text(x+bw/2,432,'DFT optimization',28,T,True,'middle');text(x+bw/2,478,'Frequency verification',26,N,False,'middle')
px,py=x+60,516;line(px,py+115,px+274,py+115,GRAY,1.3);line(px,py,px,py+115,GRAY,1.3)
pts=[(px+i*2.74,py+15+88*(1-((i-50)/50)**2)) for i in range(101)];poly(pts,col=T,width=3,name='minimum_energy_well');ell(px+137,py+103,5,G)
text(x+bw/2,704,'Verify local minima',26,N,True,'middle');text(x+bw/2,747,'No imaginary frequencies',24,GRAY,False,'middle')
# Energies and populations: lower energy corresponds to larger population.
x=xs[2];text(x+bw/2,245,'Energy → population',28,G,True,'middle')
ys=[488,425,362,299];widths=[151,96,49,25]
for i,(y,ww,cc) in enumerate(zip(ys,widths,[T,P,G,'#76BCB3'])):
 line(x+42,y,x+144,y,N,2.5,name='relative_energy_level');text(x+34,y-7,'G'+str(i+1),24,GRAY,False,'end');rect(x+202,y-15,ww,30,cc,None,3,'population_weight_'+str(i+1))
arrow(x+156,393,x+190,393,G,2.2,7)
text(x+bw/2,566,'pᵢ ∝ exp(−ΔGᵢ/RT)',29,N,True,'middle','boltzmann_relation')
text(x+bw/2,622,'ΔE / ΔH / ΔG',27,GRAY,False,'middle')
text(x+bw/2,704,'Evaluate ensemble weights',25,N,True,'middle');text(x+bw/2,747,'Boltzmann / sampled weights',24,GRAY,False,'middle')
# Separate electronic and vibrational property calculations.
x=xs[3];rect(x+15,212,bw-30,246,'#E2F2EE',None,13,'electronic_property_branch');text(x+33,256,'ECD',35,T,True);text(x+125,254,'TDDFT',27,N,True)
line(x+42,389,x+133,389,N,2);line(x+42,319,x+133,319,N,2);arrow(x+87,385,x+87,323,T,3,8);text(x+141,326,'Sₙ',24,GRAY);text(x+141,398,'S₀',24,GRAY);sticks(x+209,310,127,94,T,'ecd');text(x+bw/2,442,'Excitation energies • Rₙ',25,N,False,'middle')
rect(x+15,477,bw-30,229,'#EEE7F4',None,13,'vibrational_property_branch');text(x+33,522,'VCD',35,P,True);text(x+125,520,'DFT',27,N,True)
# Generic bond stretching; not a claim about a calculated normal mode.
line(x+53,602,x+123,602,'#7A8590',4);sphere(x+51,602,12,'#596574');sphere(x+125,602,13,RED);arrow(x+44,577,x+19,577,P,2.3,7);arrow(x+130,577,x+155,577,P,2.3,7);sticks(x+209,559,127,94,P,'vcd')
text(x+bw/2,687,'Normal modes • Rₖ',25,N,False,'middle');text(x+bw/2,747,'HFF • APT • AAT',25,GRAY,False,'middle')
# Schematic broadened / weighted spectral comparison, with meaningful visible mismatch.
x=xs[4];text(x+bw/2,245,'S̄ = Σᵢ pᵢ Sᵢ',32,N,True,'middle');text(x+25,296,'ECD',28,T,True);spectrum(x+49,314,288,100,T,'ecd',True,'ECD_schematic_comparison');text(x+333,450,'λ (nm)',24,GRAY,False,'end')
text(x+25,493,'VCD',28,P,True);spectrum(x+49,510,288,100,P,'vcd',True,'VCD_schematic_comparison');text(x+bw/2,652,'Wavenumber (cm⁻¹)',24,GRAY,False,'middle')
line(x+35,690,x+77,690,T,3);text(x+88,698,'Calc.',24,N);line(x+204,690,x+246,690,GRAY,2,True);text(x+257,698,'Exp.',24,N)
rect(x+17,722,bw-34,92,'#FFF0CF',None,11,'stereochemical_interpretation');text(x+bw/2,758,'Absolute configuration',27,N,True,'middle');text(x+bw/2,793,'& conformation',27,N,True,'middle')
# Shared influence, rather than additional mandatory sequential steps.
rect(60,843,2080,55,'#E1F0EF',None,15,'ensemble_reliability_message');text(1100,881,'Sampling + reliable populations govern the averaged spectrum',32,N,True,'middle')
for x,ww in [(60,650),(745,710),(1490,650)]:rect(x,930,ww,133,'white',BORDER,14,'supporting_method')
# Explicit water shell around a representative solute center.
sphere(111,996,12,'#596574')
for cx,cy,ang in [(157,966,.2),(164,1016,1.5),(92,1035,-1.1)]:
 hx1,hy1=cx+13*math.cos(ang-.65),cy+13*math.sin(ang-.65);hx2,hy2=cx+13*math.cos(ang+.65),cy+13*math.sin(ang+.65)
 line(cx,cy,hx1,hy1,'#9CAAB2',2);line(cx,cy,hx2,hy2,'#9CAAB2',2);sphere(cx,cy,6,RED);sphere(hx1,hy1,3.5,'#F1F3F6');sphere(hx2,hy2,3.5,'#F1F3F6')
text(240,976,'Solvent environment',30,T,True);text(240,1011,'PCM / SMD • explicit solvent',25,N);text(240,1045,'QM/MM',25,GRAY)
# Time trajectory symbol.
pts=[(776+i*2.1,1005+18*math.sin(i*.31)+6*math.cos(i*.7)) for i in range(55)];poly(pts,col=T,width=2.7,name='sampling_trajectory');text(925,976,'Dynamics & ensembles',30,T,True);text(925,1011,'MD • enhanced sampling',25,N);text(925,1045,'Convergence & uncertainty',25,GRAY)
# A small parameter-learning graph, not a claim of an actual trained model.
loc=[(1521,970),(1521,1025),(1561,956),(1561,997),(1561,1038),(1601,978),(1601,1020)]
for i in [0,1]:
 for j in [2,3,4]:line(*loc[i],*loc[j],'#BAC6D1',1.4)
for i in [2,3,4]:
 for j in [5,6]:line(*loc[i],*loc[j],'#BAC6D1',1.4)
for i,(xx,yy) in enumerate(loc):ell(xx,yy,5,P if i<5 else T)
text(1640,976,'Emerging approaches',30,P,True);text(1640,1011,'AI / ML • exciton ECD',25,N);text(1640,1045,'Population refinement',25,GRAY)
text(1100,1101,'Representative structures and schematic plots illustrate a general workflow, not a single-molecule dataset.',24,GRAY,False,'middle','schematic_disclaimer')
# Export all formats from the SAME scene graph.
pdfmetrics.registerFont(TTFont('ArialGA','/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf'));pdfmetrics.registerFont(TTFont('ArialGABold','/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf'))
pdfmetrics.registerFont(TTFont('DejaVuGA','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'));pdfmetrics.registerFont(TTFont('DejaVuGABold','/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'))
c=canvas.Canvas(str(O/'Pharmaceuticals_workflow_GA_preview.pdf'),pagesize=(W,H));c.setFillColor('white');c.rect(0,0,W,H,fill=1,stroke=0)
parts=[f'<svg xmlns="http://www.w3.org/2000/svg" width="4400" height="2240" viewBox="0 0 {W} {H}"><title>Editable ensemble-centered ECD/VCD graphical abstract</title><desc>Original conceptual vector diagram. All structures and spectra are schematic; no embedded raster images.</desc><rect width="2200" height="1120" fill="white"/>']
r=Presentation();r.slide_width=Inches(W/100);r.slide_height=Inches(H/100);s=r.slides.add_slide(r.slide_layouts[6]);s.background.fill.solid();s.background.fill.fore_color.rgb=RGBColor(255,255,255)

def fillline(sh,fill=None,col=None,width=1.5,dash=False):
 if fill:sh.fill.solid();sh.fill.fore_color.rgb=RGBColor.from_string('FFFFFF' if fill=='white' else fill.lstrip('#'))
 else:sh.fill.background()
 if col:sh.line.color.rgb=RGBColor.from_string(col.lstrip('#'));sh.line.width=Pt(width*.72)
 else:sh.line.fill.background()
 if dash:sh.line.dash_style=MSO_LINE_DASH_STYLE.DASH
for i,a in enumerate(scene):
 kind=a['kind'];name=f'{i:03d}_'+a['name']
 if kind in ['rect','ellipse']:
  x,y,ww,hh=a['x'],a['y'],a['w'],a['h'];fil=a['fill'];stroke=a.get('stroke');typ=MSO_SHAPE.OVAL if kind=='ellipse' else MSO_SHAPE.ROUNDED_RECTANGLE if a['r'] else MSO_SHAPE.RECTANGLE
  sh=s.shapes.add_shape(typ,Inches(x/100),Inches(y/100),Inches(ww/100),Inches(hh/100));fillline(sh,fil,stroke);sh.name=name
  if kind=='rect':
   if a['r']:sh.adjustments[0]=min(.5,a['r']/min(ww,hh))
   parts.append(f'<rect id="{name}" x="{x}" y="{y}" width="{ww}" height="{hh}" rx="{a["r"]}" fill="{fil}" stroke="{stroke or "none"}" stroke-width="1.5"/>');c.setFillColor(fil);c.setStrokeColor(stroke or fil);c.roundRect(x,H-y-hh,ww,hh,a['r'],stroke=bool(stroke),fill=1)
  else:
   parts.append(f'<ellipse id="{name}" cx="{x+ww/2}" cy="{y+hh/2}" rx="{ww/2}" ry="{hh/2}" fill="{fil}"/>');c.setFillColor(fil);c.ellipse(x,H-y-hh,x+ww,H-y,stroke=0,fill=1)
 elif kind=='text':
  x,y,txt,size=a['x'],a['y'],a['t'],a['size'];fn=('DejaVuGA' if a['font']=='DejaVu Sans' else 'ArialGA')+('Bold' if a['bold'] else '');tw=pdfmetrics.stringWidth(txt,fn,size);align=a['align'];left=x-tw/2-3 if align=='middle' else x-tw-3 if align=='end' else x-2
  # Deliberately size each text box to its content so only the target label is selected.
  sh=s.shapes.add_textbox(Inches(left/100),Inches((y-size*.93)/100),Inches((tw+8)/100),Inches(size*1.35/100));sh.name=name;tf=sh.text_frame;tf.margin_left=tf.margin_right=tf.margin_top=tf.margin_bottom=0;tf.word_wrap=False
  pp=tf.paragraphs[0];pp.text=txt;pp.font.name=a['font'];pp.font.size=Pt(size*.72);pp.font.bold=a['bold'];pp.font.color.rgb=RGBColor.from_string('FFFFFF' if a['col']=='white' else a['col'].lstrip('#'));pp.space_after=Pt(0);pp.line_spacing=1
  pp.alignment=PP_ALIGN.CENTER if align=='middle' else PP_ALIGN.RIGHT if align=='end' else PP_ALIGN.LEFT
  parts.append(f'<text id="{name}" x="{x}" y="{y}" fill="{a["col"]}" font-family="{a["font"]},sans-serif" font-size="{size}" font-weight="{700 if a["bold"] else 400}" text-anchor="{align}">{escape(txt)}</text>');c.setFillColor(a['col']);c.setFont(fn,size);{'start':c.drawString,'middle':c.drawCentredString,'end':c.drawRightString}[align](x,H-y,txt)
 else:
  pts=a['pts'];path='M '+' L '.join(f'{x:.3f},{y:.3f}' for x,y in pts)+(' Z' if a['closed'] else '');parts.append(f'<path id="{name}" d="{path}" fill="{a["fill"] or "none"}" stroke="{a["col"] or "none"}" stroke-width="{a["width"]}"'+(' stroke-dasharray="7 5"' if a['dash'] else '')+'/>')
  p=c.beginPath();p.moveTo(pts[0][0],H-pts[0][1]);[p.lineTo(x,H-y) for x,y in pts[1:]]
  if a['closed']:p.close()
  c.setFillColor(a['fill'] or 'white');c.setStrokeColor(a['col'] or 'white');c.setLineWidth(a['width']);c.setDash([7,5] if a['dash'] else []);c.drawPath(p,fill=bool(a['fill']),stroke=bool(a['col']) and a['width']>0);c.setDash([])
  builder=s.shapes.build_freeform(pts[0][0],pts[0][1],scale=9144);builder.add_line_segments(pts[1:],close=a['closed']);sh=builder.convert_to_shape();sh.name=name;fillline(sh,a['fill'],a['col'] if a['width'] else None,a['width'],a['dash'])
c.showPage();c.save();parts.append('</svg>');(O/'Pharmaceuticals_workflow_GA.svg').write_text('\n'.join(parts));(O/'editable_scene.json').write_text(json.dumps(scene,ensure_ascii=False,indent=2))
s.notes_slide.notes_text_frame.text='Original graphical abstract for manuscript pharmaceuticals-4710854. Manuscript sections: 2.1 search; 2.2 geometry/frequency; 2.3 conformational energies/populations; 2.4 parallel ECD/VCD properties; 2.5 broadening/weighting/comparison; 2.6 solvent effects; 3.1 large-system ECD exciton models; 3.2 AI-assisted analysis/population refinement/prediction; 4 workflow-wide reliability. Molecular models are representative independently generated ETKDG/MMFF geometries, not a molecule-specific dataset or DFT results. Precise model identity is documented for provenance, not claimed as the subject of the entire workflow. Design reference actually viewed: Duignan, The Potential of Neural Network Potentials, DOI10.1021/acsphyschemau.4c00004. Only the general method-to-method pictorial approach is borrowed, not the original figure composition or artwork. PES, energies, normal-mode arrows and spectra are schematic. H denotes the mass-weighted Hessian. HFF: harmonic force field; APT: atomic polar tensor; AAT: atomic axial tensor. Sources and access levels are documented in the accompanying reference guide. Boltzmann ΔG shown as representative, not universally required. MD populations require appropriate sampling. No original figure copied. All shapes, labels, bonds and curves editable; no embedded raster images. Source scene exported identically to SVG and PDF. AI-assisted concept/layout/code; authors must review and disclose per editor request.'
from pptx.oxml.xmlchemy import OxmlElement
for obj in s.shapes:
 for ef in obj._element.xpath('.//a:effectRef'):ef.set('idx','0')
 sppr=obj._element.find('{http://schemas.openxmlformats.org/presentationml/2006/main}spPr')
 if sppr is not None:sppr.append(OxmlElement('a:effectLst'))
r.save(O/'Pharmaceuticals_workflow_GA.pptx')
pdf=fitz.open(O/'Pharmaceuticals_workflow_GA_preview.pdf');page=pdf[0];page.get_pixmap(matrix=fitz.Matrix(2,2),alpha=False).save(O/'Pharmaceuticals_GA_4400x2240.png');page.get_pixmap(matrix=fitz.Matrix(.5,.5),alpha=False).save(O/'Pharmaceuticals_GA_1100x560_preview.png')

(O/'Pharmaceuticals_workflow_GA_outlined.svg').write_text(page.get_svg_image(text_as_path=True))
print('Exported',len(s.shapes),'editable objects')
