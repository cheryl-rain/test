按用户本次粘贴的Table1六类组织：系统采样、随机采样、全局/启发式搜索、动力学采样、增强采样、自动混合采样。
能量评估方法单列：MMFF/MMFF94、AM1/PM3、GFNn-xTB。类别可交叠，CREST包含MD/MTD/GC。GC为genetic Z-matrix crossing，不等同GA。
下方是代表性静态低能候选生成和筛选路线，正文另讨论直接对MD快照计算并平均。
SVG保留29个text节点，无嵌入位图；PPT包含55个原生对象，直接修改文本框。SVG插入PPT后通常仍为整体图形；在PowerPoint编辑请打开PPTX。
也可用本地浏览器打开Edit_text_offline.html，点击文字修改，再导出SVG。
图注建议：Representative conformational-search and sampling categories discussed in this review, shown separately from low-cost energy evaluation methods. The lower sequence illustrates a candidate-generation, local-optimization, filtering and DFT-refinement route; categories can overlap and direct MD snapshot calculations provide alternative pathways.
