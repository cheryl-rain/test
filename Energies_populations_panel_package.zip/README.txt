优先在PPTX中编辑文字，或用Illustrator文件→打开SVG后使用文字工具。
若公式上下标缺字，请安装fonts目录中的DejaVu Sans普通/粗体，许可随附。
Edit_text_offline.html可点击文字修改并导出SVG。
两条布居/平均路线是互补选择，不是串行必经步骤。
详细原文对应和术语说明见DOCX。
