## 本版的主要修改
依据本轮用户粘贴的2.3.1—2.3.3重组。能量形式、热力学近似/低频处理和Shermo软件分层列出；静态能量的Boltzmann路线与MD统计/平均路线不是前后必做步骤。把原截图缺字符的ΔE下标项改为完整物理量名称，避免用不明下标代替定义。

## 上半部：2.3.1
Conformational energies and Boltzmann populations沿用小节标题。左侧G1—G4是示意Gibbs自由能排序，右侧权重与exp(−ΔG/RT)对应。等间隔能级配等比权重，保证示意关系自洽；没有能量值、温度值或分子数据。归一化公式采用ΔG作为例子，并未把它认定为普遍最优选择。用户此次纯文本中的数学对象未完整保留，公式按文字描述及标准Boltzmann定义恢复，不宣称是从所贴文本逐字复制的公式。p为布居，R为气体常数，T为绝对温度，分母为所有纳入构象的指数项求和。

## 四类能量形式
原文Table2及随后段落讨论：电子能、含ZPVE的电子能、焓、Gibbs自由能。因此图中列为Electronic energy、Electronic energy + ZPVE、Enthalpy (H)、Gibbs free energy (G)。它们是可采用的不同能量基础，不是必须依次进行的四项处理；相对能量差由各构象的所选能量相减得到。具体用哪种取决于体系和方案，不存在原文所证实的统一最佳方案。

## 多层级评估：2.3.1
Multilevel option: single-point energy + corrections是对原文“较低水平优化/频率+更高水平单点能+热力学校正”的短写。此为可选组合，不表示所有电子能都必须加校正；如果采用G，校正中涉及给定温度的热力学贡献。原文列出相同水平和多水平组合两种方式，本图只用option强调后者不是唯一方式。

## 热力学与低频处理：2.3.2
Thermodynamic corrections and low-frequency vibrations沿用原文小节名。RRHO是常用刚性转子-谐振子近似；低频模式下熵可能敏感，qRRHO用于近似校正，具有内转动特征的模式可采用hindered-rotor model。这些名称不是必须全部叠加的固定协议。Shermo单独标为Thermochemical post-processing，不与RRHO/qRRHO并列为同一类理论模型。原文还讨论对低频能量项的扩展处理，未在小图中逐一展开所有研究细节。

## 下半部：2.3.3
Conformational populations based on MD sampling是对原小节标题的缩写。充分采样和平衡是以MD统计反映热布居的重要前提。图中C1、C2、C3仅为抽象构象状态，时间序列和条形均为示意；条长按该符号序列各状态出现次数比例生成，未用实际MD数据。原文有两类路径：直接对快照谱平均，或从轨迹提取状态概率，再对各状态的光谱加权。图中用or区分，不要求先对每个快照重新进行静态Boltzmann赋权。图中不是宣称所有MD应用都只涉及平衡统计，亦不否认原文个别案例对动态效应的讨论。

## 不引入超出原文的结论
图底部强调能量形式和低频处理影响权重，并保留原文“MD统计并不必然优于局部极小值能量处理”的边界。没有声称低能构象越少越好、任何一种能量总最好、或用实验拟合自动得到真实布居。GA处理能量不确定性的详细方法在原文第3章，因此没有混入本步骤的同级方法列表。

## 英文图注
Two complementary approaches to conformational populations and spectral averaging discussed in this review. Relative conformational energies can be used to calculate Boltzmann populations; Gibbs free-energy differences are shown as an example. Electronic energy, zero-point-energy-corrected electronic energy, enthalpy and Gibbs free energy provide different energy bases, and thermochemical and low-frequency treatments may alter the resulting weights. Alternatively, adequately sampled and equilibrated MD trajectories can support direct averaging of snapshot spectra or weighting by MD-derived state probabilities. Energy levels, populations and state trajectories are schematic, not molecule-specific calculations or measured data.

## 文字及公式编辑
SVG保留30个标准text节点，PPT含65个原生对象，文字均可编辑。已验证所有SVG图形标签都在http://www.w3.org/2000/svg命名空间，Inkscape导入渲染正常。Illustrator建议用“文件→打开”后使用文字工具，不把链接置入对象直接当作文本框。可用Edit_text_offline.html点击标签编辑；编辑器按纯文字改整条标签，不提供富文本公式排版。数学上下标需支持相应字形，本包fonts目录附DejaVu Sans普通/粗体及其许可；若出现缺字，安装字体后重开SVG/PPT。

## 格式与披露
PNG2000×2840、TIFF无损LZW、SVG文字版、原生PPT及PDF预览来自同一场景。竖向局部图沿用前两步骤版式，不直接套用整张横向图文摘要的55:28比例。图形及代码由ChatGPT辅助设计，作者应审核并按稿件实际GenAI使用披露。未重新查询或宣称核实了本段所有原始参考文献，本图主要依据用户本次贴文。