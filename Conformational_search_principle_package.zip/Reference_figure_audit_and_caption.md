## 这次改变了什么
主体从“三类方法各配一个图标”改为共同搜索原理：探索构象空间、生成试探构型、局部最小化、定位极小值、按能量窗口及结构唯一性筛选。图下只按原稿小节顺序列方法名称。网格与散点不再被当作系统搜索和随机搜索的完整原理图。

## 核查范围
针对原理绘图定向选取四篇可获取原图的相关文章，共核对7幅原图：Confab图1、CONFORGE图4/6/9、Higo综述图2/8、Bayesian构象生成图1。明确区分原始方法论文和综述。本次并非声称已穷尽所有构象搜索文献。原图均实际查看；交付图自行构建，没有描摹原图像素、路径、版式或化合物。为避免再分发原图，公开文件包仅提供文献、图号、链接和对应说明，不附出版商原图副本。

## 1. Confab｜系统扭转搜索与筛选
O’Boyle NM, Vandermeersch T, Flynn CJ, Maguire AR, Hutchison GR. Confab - Systematic generation of diverse low-energy conformers. Journal of Cheminformatics. 2011;3:8. DOI:10.1186/1758-2946-3-8. https://doi.org/10.1186/1758-2946-3-8
开放全文：https://pmc.ncbi.nlm.nih.gov/articles/PMC3073927/
图1实际查看：识别可旋转键、应用扭转规则、生成候选、判断低能/多样性、过滤相似构象。用于纠正原版网格图过度简化的问题，并支持能量和多样性筛选的共同原则。这是算法/软件方法文章，不是普通综述。

## 2. CONFORGE｜两类搜索及输出集合
Seidel T, Permann C, Wieder O, Kohlbacher SM, Langer T. High-Quality Conformer Generation with CONFORGE: Algorithm and Performance Assessment. Journal of Chemical Information and Modeling. 2023;63:5549–5570. DOI:10.1021/acs.jcim.3c00563. https://doi.org/10.1021/acs.jcim.3c00563
开放全文：https://pmc.ncbi.nlm.nih.gov/articles/PMC10498443/
实际查看图4：随机候选、能量阈值、收敛及能量窗口过滤；图6：片段生成/组合及扭转驱动的系统采样；图9：能量排序及成对RMSD去重。由此提炼候选生成、最小化及能量/唯一性筛选，并非复制任何一个软件的完整流程。文中随机生成使用距离几何（图5图注及正文），不能等同于Monte Carlo；本图方法栏仍以用户原稿内容为准，不新增DG条目。本篇为原始方法研究。

## 3. Higo等综述｜构象空间与覆盖范围
Higo J, Ikebe J, Kamiya N, Nakamura H. Enhanced and effective conformational sampling of protein molecular systems for their free energy landscapes. Biophysical Reviews. 2012;4:27–44. DOI:10.1007/s12551-011-0063-6. https://doi.org/10.1007/s12551-011-0063-6
开放全文：https://pmc.ncbi.nlm.nih.gov/articles/PMC3271212/
实际查看图2和图8：能量面、采样轨迹和二维构象区域覆盖。用于参考势阱/区域及探索覆盖的表达。本图虚线只表示试探构型之间的探索关系，不声称为真实MD轨迹；本图金色箭头表示优化下降，不与采样跨能垒混为一谈。

## 4. Bayesian优化论文｜能量面与评估点
Chan L, Hutchison GR, Morris GM. Bayesian optimization for conformer generation. Journal of Cheminformatics. 2019;11:32. DOI:10.1186/s13321-019-0354-7. https://doi.org/10.1186/s13321-019-0354-7
开放全文：https://pmc.ncbi.nlm.nih.gov/articles/PMC6528340/
实际查看图1：联苯扭转角与能量面、迭代评估点及采集函数。仅借鉴将构型评估位置对应到能量空间的原理表达，不使用联苯结构或原始能量，不把Bayesian优化加入原稿方法列表。该文属于原始算法研究。

## CREST信息的核实层级
Pracht P, et al. CREST—A program for the exploration of low-energy molecular chemical space. Journal of Chemical Physics. 2024;160:114110. DOI:10.1063/5.0197592。本轮仅检索到元数据/摘要，未获取原图，不作为实际视觉参考。CREST方法名称及组合主要依用户原稿2.1.3及原稿已引[71,72]等。

## 主体画法与科学逻辑
左图为自行构建的四势阱解析势能面，φ1/φ2表示两个抽象扭转自由度，不对应具体分子。青绿色点为试探构型；灰青色虚线为构型探索关系，不是固定算法的真实连续轨迹。金色线为根据该示意解析势能函数做下降得到的局部优化方向，保证局部优化箭头降低能量。M1—M4为局部极小值位置。右侧能级排序与同一示意函数的四个极小值相对高低一致；能量窗口保留M1—M3、排除较高的M4。多个起点可能到达同一极小值，因此还需按结构相似性去重。解析函数仅用于几何逻辑自洽，不构成论文新计算结果，也不给出能量数值。

## 与原稿的对应
2.1总述：生成候选构象、低成本能量评估、局部优化、能量窗口及高水平精修。
2.1.1：Systematic torsion scans、MC、GA；方法名称按原稿列举，不把网格或散点等同完整算法。
2.1.2：MD、REMD、MTD。
2.1.3：CREST与GFNn-xTB、MTD/MD/GC组合。GC为genetic Z-matrix crossing，不能与一般GA混称。
三组按文章组织列出，互相可组合，不是互斥分类。图中仅表示代表性的低能候选生成/筛选路线；正文另讨论直接对MD快照计算及平均光谱，不能把该筛选路线强制用于所有MD应用。

## 英文图注
Principle of a representative conformational-search and selection workflow. Trial configurations explore different regions of a schematic torsional potential-energy surface; local optimization identifies minima. Energy-window filtering and removal of structurally redundant solutions provide a representative low-energy candidate ensemble for higher-level refinement. Method names are grouped separately according to the organization of the review and denote complementary, potentially overlapping strategies. All landscapes, trial configurations and energy levels are conceptual illustrations, not a specific molecular system or an algorithm-performance comparison.

## 文件编辑
SVG文字版Conformational_search_principle.svg包含原生<text>节点，可在Inkscape/Illustrator使用文字工具修改；PPTX包含110个原生对象。outlined.svg为文字转轮廓版本，仅用于字体安全输出，不可按文字修改。PNG4400×2240，比例55:28；TIFF为LZW无损版本，PDF为矢量预览。图形/文字与路径均自行绘制，不嵌入原文图像或其他位图。

## GenAI披露
ChatGPT辅助文献图形核查的整理、图文布局及绘图代码生成。沿用稿件中实际的GenAI使用披露，作者审核后确认责任；不声称本图是新的实验数据或分子量子计算。