from pathlib import Path
import math,json,zipfile
from xml.sax.saxutils import escape
import numpy as np
from pptx import Presentation
from pptx.util import Inches,Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN
from pptx.enum.dml import MSO_LINE_DASH_STYLE
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from fontTools.ttLib import TTFont as FT
import fitz
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
O=Path(__file__).resolve().parent;W,H=2200,1120
N='#17364E';T='#07867F';P='#80529D';G='#B98426';GRAY='#647585';BORDER='#C9D5DE';RED='#D74646'
regular='/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf';bold='/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf';cmap=FT(regular).getBestCmap();scene=[]
def rect(x,y,w,h,fill='white',stroke=None,r=12,name='panel'):scene.append(dict(kind='rect',x=x,y=y,w=w,h=h,fill=fill,stroke=stroke,r=r,name=name))
def ell(x,y,r,fill,name='atom'):scene.append(dict(kind='ellipse',x=x-r,y=y-r,w=r*2,h=r*2,fill=fill,name=name))
def text(x,y,t,size=28,col=N,bold=False,align='start',name='text'):
 assert size>=24
 scene.append(dict(kind='text',x=x,y=y,t=t,size=size,col=col,bold=bold,align=align,font='DejaVu Sans' if any(ord(ch) not in cmap for ch in t) else 'Arial',name=name))
def poly(pts,fill=None,col=N,width=2,closed=False,dash=False,name='path'):scene.append(dict(kind='path',pts=[tuple(map(float,p)) for p in pts],col=col,width=width,dash=dash,fill=fill,closed=closed,name=name))
def line(x1,y1,x2,y2,col=N,width=2,dash=False,name='line'):poly([(x1,y1),(x2,y2)],col=col,width=width,dash=dash,name=name)
def arrow(x1,y1,x2,y2,col=N,width=3,head=10,dash=False,name='arrow'):
 dx=x2-x1;dy=y2-y1;l=math.hypot(dx,dy);ux,uy=dx/l,dy/l;bx,by=x2-ux*head,y2-uy*head;line(x1,y1,bx,by,col,width,dash,name+'_shaft');poly([(x2,y2),(bx-uy*head*.58,by+ux*head*.58),(bx+uy*head*.58,by-ux*head*.58)],col,col,0,True,name=name+'_head')
text(1100,66,'Conformational search: exploring and selecting low-energy minima',42,N,True,'middle','title')
text(1100,110,'Principle schematic • representative search-and-selection route',28,GRAY,False,'middle')
# Main figure explains a shared principle; methods are listed separately below.
text(520,180,'Explore conformational space',32,T,True,'middle')
text(1638,180,'Rank, filter and retain distinct minima',32,N,True,'middle')
px,py,pw,ph=145,224,929,450
centers=[(-1.4,-1.05),(1.25,1.3),(1.5,-1.2),(-1.4,1.5)];depths=[2.9,2.2,1.9,.8];wx=[.95,.85,.7,.65];wy=[.9,.8,.75,.65]
def E(p):
 u,v=p;return .045*(u*u+v*v)-sum(d*np.exp(-((u-c[0])**2/ax+(v-c[1])**2/ay)) for c,d,ax,ay in zip(centers,depths,wx,wy))
def grad(p):
 u,v=p;g=np.array([.09*u,.09*v],dtype=float)
 for c,d,ax,ay in zip(centers,depths,wx,wy):
  ex=d*np.exp(-((u-c[0])**2/ax+(v-c[1])**2/ay));g+=np.array([2*(u-c[0])/ax*ex,2*(v-c[1])/ay*ex])
 return g
def minimize(seed):
 p=np.array(seed,dtype=float);path=[p.copy()]
 for _ in range(190):
  gg=grad(p)
  if np.linalg.norm(gg)<1e-7:break
  step=.18
  for _ in range(20):
   q=np.clip(p-step*gg,-2.98,2.98)
   if E(q)<E(p):break
   step*=.5
  p=q;path.append(p.copy())
 return np.array(path)
def pos(u,v):return (px+(u+3)/6*pw,py+(3-v)/6*ph)
xx=np.linspace(-3,3,150);yy=np.linspace(-3,3,130);X,Y=np.meshgrid(xx,yy);Z=np.array([[E((u,v)) for u in xx] for v in yy]);levels=[-2.7,-2.1,-1.6,-1.1,-.65,-.25,.15]
rect(px,py,pw,ph,'#FAFCFB',None,0,'schematic_energy_landscape')
fig,ax=plt.subplots();co=ax.contour(X,Y,Z,levels=levels)
for k,segs in enumerate(co.allsegs):
 for seg in segs:
  if len(seg)>2:poly([pos(u,v) for u,v in seg],col='#9BB7B2',width=1.5,name='potential_contour')
plt.close(fig);line(px,py,px,py+ph,GRAY,1.5);line(px,py+ph,px+pw,py+ph,GRAY,1.5)
text(px+pw/2,py+ph+39,'φ₁',28,GRAY,False,'middle');text(px-38,py+ph/2,'φ₂',28,GRAY,False,'middle')
# Sample points and trial-order links are conceptual configurations, not a physical MD trajectory.
seeds=[(-2.1,-1.65),(-.7,-.35),(.5,1.95),(1.9,1.75),(2.05,-1.8),(.7,-.55),(-1.95,2.1)]
trial=[seeds[i] for i in [0,1,6,2,3,5,4]];poly([pos(*p) for p in trial],col='#88B9B2',width=1.7,dash=True,name='trial_configuration_exploration')
for seed in seeds:
 pth=minimize(seed);points=[pos(*p) for p in pth];poly(points,col=G,width=2.8,name='downhill_local_optimization')
 if len(points)>5:arrow(*points[1],*points[min(5,len(points)-1)],G,2.6,8,name='optimization_direction')
 x,y=pos(*seed);ell(x,y,5.5,'white','trial_halo');ell(x,y,3.8,T,'trial_configuration')
mins=[minimize(c)[-1] for c in centers]
for i,p in enumerate(mins):
 x,y=pos(*p);ell(x,y,10,'white','minimum_halo');ell(x,y,6.8,G if i<3 else GRAY,'located_minimum');text(x+14,y+13,'M'+str(i+1),25,N,True)
# Selection is consistent with the same four analytic minima; no numeric energies shown.
arrow(1110,447,1197,447,N,3,11,name='to_energy_ranking')
ex,ey,ew,eh=1240,225,865,451
rect(ex,ey,ew,eh,'#F7F9FB',None,14,'energy_ranking_panel')
vals=np.array([E(p) for p in mins]);rel=vals-vals.min();maxe=max(rel)+.35
energy_y=lambda v:ey+eh-45-v/maxe*(eh-80)
cutoff=(rel[2]+rel[3])/2;cy=energy_y(cutoff)
rect(ex+97,cy,520,ey+eh-25-cy,'#E5F1EC',None,0,'accepted_energy_window')
arrow(ex+62,ey+eh-25,ex+62,ey+22,GRAY,1.5,8,name='relative_energy_axis');text(ex+42,ey+18,'ΔE',25,GRAY,False,'end')
for i,re in enumerate(rel):
 y=energy_y(re);c=T if i<3 else GRAY;line(ex+120,y,ex+330,y,c,3,name='ranked_minimum_energy');text(ex+110,y+9,'M'+str(i+1),26,N,True,'end')
 if i==3:text(ex+360,y+9,'Outside energy window',25,GRAY)
 else:text(ex+360,y+9,'Retain',25,T,True)
line(ex+95,cy,ex+632,cy,G,1.8,True);text(ex+650,cy+8,'Energy cutoff',25,G)
# A duplicate found from a second starting point maps to the same optimized minimum, not another state.
y=energy_y(rel[1]);line(ex+120,y-14,ex+330,y-14,'#BFCBC8',1.5,True);text(ex+650,y+4,'Merge duplicates',24,GRAY)
text(610,756,'Trial configurations',26,T,False,'middle');ell(415,747,4.3,T,'legend_trial')
line(780,747,817,747,G,3);text(834,756,'Local optimization',26,G)
text(1655,728,'Energy window + structural uniqueness',27,N,True,'middle')
# Method names only, grouped in the article's order; no fabricated per-method icons.
text(1100,815,'Methods discussed in this review',28,N,True,'middle')
method=[(60,680,'Systematic & stochastic','Systematic torsion scans • MC • GA',T),(760,680,'MD & enhanced sampling','MD • REMD • MTD',P),(1460,680,'Automated hybrid search','CREST: GFNn-xTB • MTD / MD / GC',G)]
for xx,ww,heading,names,c in method:
 rect(xx,849,ww,130,'#F0F6F4' if c==T else '#F4F0F7' if c==P else '#FCF6EB',None,13,'method_group')
 text(xx+ww/2,894,heading,29,c,True,'middle');text(xx+ww/2,945,names,25,N,False,'middle')
text(1100,1032,'Output: a representative low-energy candidate ensemble for higher-level refinement',29,N,True,'middle')
text(1100,1094,'Schematic potential and search steps; no specific molecule, numerical energies or algorithm performance data.',24,GRAY,False,'middle','disclaimer')
# Export all formats from the SAME scene graph.
pdfmetrics.registerFont(TTFont('ArialGA','/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf'));pdfmetrics.registerFont(TTFont('ArialGABold','/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf'))
pdfmetrics.registerFont(TTFont('DejaVuGA','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'));pdfmetrics.registerFont(TTFont('DejaVuGABold','/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'))
c=canvas.Canvas(str(O/'Conformational_search_principle_preview.pdf'),pagesize=(W,H));c.setFillColor('white');c.rect(0,0,W,H,fill=1,stroke=0)
parts=[f'<svg xmlns="http://www.w3.org/2000/svg" width="4400" height="2240" viewBox="0 0 {W} {H}"><title>Editable ensemble-centered ECD/VCD graphical abstract</title><desc>Original molecule-independent conceptual vector diagram. All landscapes and spectra are schematic; no molecular structures or embedded raster images.</desc><rect width="2200" height="1120" fill="white"/>']
r=Presentation();r.slide_width=Inches(W/100);r.slide_height=Inches(H/100);s=r.slides.add_slide(r.slide_layouts[6]);s.background.fill.solid();s.background.fill.fore_color.rgb=RGBColor(255,255,255)

def fillline(sh,fill=None,col=None,width=1.5,dash=False):
 if fill:sh.fill.solid();sh.fill.fore_color.rgb=RGBColor.from_string('FFFFFF' if fill=='white' else fill.lstrip('#'))
 else:sh.fill.background()
 if col:sh.line.color.rgb=RGBColor.from_string(col.lstrip('#'));sh.line.width=Pt(width*.72)
 else:sh.line.fill.background()
 if dash:sh.line.dash_style=MSO_LINE_DASH_STYLE.DASH
for i,a in enumerate(scene):
 kind=a['kind'];name=f'{i:03d}_'+a['name']
 if kind in ['rect','ellipse']:
  x,y,ww,hh=a['x'],a['y'],a['w'],a['h'];fil=a['fill'];stroke=a.get('stroke');typ=MSO_SHAPE.OVAL if kind=='ellipse' else MSO_SHAPE.ROUNDED_RECTANGLE if a['r'] else MSO_SHAPE.RECTANGLE
  sh=s.shapes.add_shape(typ,Inches(x/100),Inches(y/100),Inches(ww/100),Inches(hh/100));fillline(sh,fil,stroke);sh.name=name
  if kind=='rect':
   if a['r']:sh.adjustments[0]=min(.5,a['r']/min(ww,hh))
   parts.append(f'<rect id="{name}" x="{x}" y="{y}" width="{ww}" height="{hh}" rx="{a["r"]}" fill="{fil}" stroke="{stroke or "none"}" stroke-width="1.5"/>');c.setFillColor(fil);c.setStrokeColor(stroke or fil);c.roundRect(x,H-y-hh,ww,hh,a['r'],stroke=bool(stroke),fill=1)
  else:
   parts.append(f'<ellipse id="{name}" cx="{x+ww/2}" cy="{y+hh/2}" rx="{ww/2}" ry="{hh/2}" fill="{fil}"/>');c.setFillColor(fil);c.ellipse(x,H-y-hh,x+ww,H-y,stroke=0,fill=1)
 elif kind=='text':
  x,y,txt,size=a['x'],a['y'],a['t'],a['size'];fn=('DejaVuGA' if a['font']=='DejaVu Sans' else 'ArialGA')+('Bold' if a['bold'] else '');tw=pdfmetrics.stringWidth(txt,fn,size);align=a['align'];left=x-tw/2-3 if align=='middle' else x-tw-3 if align=='end' else x-2
  # Deliberately size each text box to its content so only the target label is selected.
  sh=s.shapes.add_textbox(Inches(left/100),Inches((y-size*.93)/100),Inches((tw+8)/100),Inches(size*1.35/100));sh.name=name;tf=sh.text_frame;tf.margin_left=tf.margin_right=tf.margin_top=tf.margin_bottom=0;tf.word_wrap=False
  pp=tf.paragraphs[0];pp.text=txt;pp.font.name=a['font'];pp.font.size=Pt(size*.72);pp.font.bold=a['bold'];pp.font.color.rgb=RGBColor.from_string('FFFFFF' if a['col']=='white' else a['col'].lstrip('#'));pp.space_after=Pt(0);pp.line_spacing=1
  pp.alignment=PP_ALIGN.CENTER if align=='middle' else PP_ALIGN.RIGHT if align=='end' else PP_ALIGN.LEFT
  parts.append(f'<text id="{name}" x="{x}" y="{y}" fill="{a["col"]}" font-family="{a["font"]},sans-serif" font-size="{size}" font-weight="{700 if a["bold"] else 400}" text-anchor="{align}">{escape(txt)}</text>');c.setFillColor(a['col']);c.setFont(fn,size);{'start':c.drawString,'middle':c.drawCentredString,'end':c.drawRightString}[align](x,H-y,txt)
 else:
  pts=a['pts'];path='M '+' L '.join(f'{x:.3f},{y:.3f}' for x,y in pts)+(' Z' if a['closed'] else '');parts.append(f'<path id="{name}" d="{path}" fill="{a["fill"] or "none"}" stroke="{a["col"] or "none"}" stroke-width="{a["width"]}"'+(' stroke-dasharray="7 5"' if a['dash'] else '')+'/>')
  p=c.beginPath();p.moveTo(pts[0][0],H-pts[0][1]);[p.lineTo(x,H-y) for x,y in pts[1:]]
  if a['closed']:p.close()
  c.setFillColor(a['fill'] or 'white');c.setStrokeColor(a['col'] or 'white');c.setLineWidth(a['width']);c.setDash([7,5] if a['dash'] else []);c.drawPath(p,fill=bool(a['fill']),stroke=bool(a['col']) and a['width']>0);c.setDash([])
  builder=s.shapes.build_freeform(pts[0][0],pts[0][1],scale=9144);builder.add_line_segments(pts[1:],close=a['closed']);sh=builder.convert_to_shape();sh.name=name;fillline(sh,a['fill'],a['col'] if a['width'] else None,a['width'],a['dash'])
c.showPage();c.save();parts.append('</svg>');(O/'Conformational_search_principle.svg').write_text('\n'.join(parts));(O/'editable_scene.json').write_text(json.dumps(scene,ensure_ascii=False,indent=2))
s.notes_slide.notes_text_frame.text='Original conceptual conformational-search principle diagram, not a comparison of algorithm performance. Primary literature examined before drawing: Confab DOI10.1186/1758-2946-3-8 Figure1; CONFORGE DOI10.1021/acs.jcim.3c00563 Figures4,6,9; Higo review DOI10.1007/s12551-011-0063-6 Figures2,8. These original figures were viewed; no pixels, layout or paths copied. The central illustration shows schematic trial configurations on an analytic four-basin torsional potential, local minimization, energy-window selection and removal of duplicate minima. The original analytic function was used to keep arrows downhill and rank the four minima consistently, but no molecule-specific energies or real trajectories are claimed. Method names are listed separately in the manuscript order: systematic/stochastic searches, MD/enhanced sampling, automated CREST hybrid search. They are complementary and overlapping, not exclusive algorithm classes. GA differs from CREST GC. The pipeline is a representative low-energy-candidate route; the manuscript also discusses direct calculations/averaging over MD snapshots. Live SVG text and native PPT shapes are editable. AI-assisted figure code and design for author review/disclosure.'
from pptx.oxml.xmlchemy import OxmlElement
for obj in s.shapes:
 for ef in obj._element.xpath('.//a:effectRef'):ef.set('idx','0')
 sppr=obj._element.find('{http://schemas.openxmlformats.org/presentationml/2006/main}spPr')
 if sppr is not None:sppr.append(OxmlElement('a:effectLst'))
r.save(O/'Conformational_search_principle.pptx')
pdf=fitz.open(O/'Conformational_search_principle_preview.pdf');page=pdf[0];page.get_pixmap(matrix=fitz.Matrix(2,2),alpha=False).save(O/'Conformational_search_principle_4400x2240.png');page.get_pixmap(matrix=fitz.Matrix(.5,.5),alpha=False).save(O/'Conformational_search_principle_preview.png')

(O/'Conformational_search_principle_outlined.svg').write_text(page.get_svg_image(text_as_path=True))
print('Exported',len(s.shapes),'editable objects')
