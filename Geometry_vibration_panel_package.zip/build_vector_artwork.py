from pathlib import Path
import math,json,zipfile
from xml.sax.saxutils import escape
import numpy as np
from pptx import Presentation
from pptx.util import Inches,Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN
from pptx.enum.dml import MSO_LINE_DASH_STYLE
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from fontTools.ttLib import TTFont as FT
import fitz
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
O=Path(__file__).resolve().parent;W,H=1000,1420
N='#17364E';T='#07867F';P='#80529D';G='#B98426';GRAY='#647585';BORDER='#C9D5DE';RED='#D74646'
regular='/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf';bold='/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf';cmap=FT(regular).getBestCmap();scene=[]
def rect(x,y,w,h,fill='white',stroke=None,r=12,name='panel'):scene.append(dict(kind='rect',x=x,y=y,w=w,h=h,fill=fill,stroke=stroke,r=r,name=name))
def ell(x,y,r,fill,name='atom'):scene.append(dict(kind='ellipse',x=x-r,y=y-r,w=r*2,h=r*2,fill=fill,name=name))
def text(x,y,t,size=28,col=N,bold=False,align='start',name='text'):
 assert size>=24
 scene.append(dict(kind='text',x=x,y=y,t=t,size=size,col=col,bold=bold,align=align,font='DejaVu Sans' if any(ord(ch) not in cmap for ch in t) else 'Arial',name=name))
def poly(pts,fill=None,col=N,width=2,closed=False,dash=False,name='path'):scene.append(dict(kind='path',pts=[tuple(map(float,p)) for p in pts],col=col,width=width,dash=dash,fill=fill,closed=closed,name=name))
def line(x1,y1,x2,y2,col=N,width=2,dash=False,name='line'):poly([(x1,y1),(x2,y2)],col=col,width=width,dash=dash,name=name)
def arrow(x1,y1,x2,y2,col=N,width=3,head=10,dash=False,name='arrow'):
 dx=x2-x1;dy=y2-y1;l=math.hypot(dx,dy);ux,uy=dx/l,dy/l;bx,by=x2-ux*head,y2-uy*head;line(x1,y1,bx,by,col,width,dash,name+'_shaft');poly([(x2,y2),(bx-uy*head*.58,by+ux*head*.58),(bx+uy*head*.58,by-ux*head*.58)],col,col,0,True,name=name+'_head')
rect(20,15,960,1390,'#F6F9F9',None,30,'portrait_background')
text(500,81,'2  Geometry Optimization',47,N,True,'middle','title_line1')
text(500,139,'& Vibrational Analysis',47,N,True,'middle','title_line2')
# Schematic convergence diagnostics, visually distinct from conformational-space exploration.
px,pw=139,735;py,ph=227,121
text(px,206,'Energy',30,N,True,'start','energy_plot_title')
line(px,py,px,py+ph,GRAY,2);line(px,py+ph,px+pw,py+ph,GRAY,2)
en=[.95,.60,.70,.32,.19,.13,.105,.098,.095,.094]
ep=[(px+pw*i/(len(en)-1),py+(1-e)*ph) for i,e in enumerate(en)]
poly(ep,col=T,width=3.5,name='schematic_energy_convergence')
for pp in ep:ell(*pp,4.6,T,'energy_step')
text(px-35,py+64,'E',30,GRAY,False,'middle')
text(px,401,'Gradient norm',30,N,True,'start','gradient_plot_title')
gy,gh=423,112;gv=[.93,.64,.36,.43,.18,.105,.06,.023,.012,.007]
gp=[(px+pw*i/(len(gv)-1),gy+(1-g)*gh) for i,g in enumerate(gv)]
line(px,gy,px,gy+gh,GRAY,2);line(px,gy+gh,px+pw,gy+gh,GRAY,2)
poly(gp,col=P,width=3.5,name='schematic_gradient_convergence')
for pp in gp:ell(*pp,4.6,P,'gradient_step')
limit=gy+(1-.07)*gh;line(px+8,limit,px+pw,limit,G,2,True)
text(px+pw-7,gy+73,'Convergence threshold',25,G,False,'end','gradient_tolerance')
ell(*gp[-1],6.5,G,'converged_step')
text(px-37,gy+64,'‖∇E‖',27,GRAY,False,'middle')
text(500,579,'Optimization steps',29,GRAY,False,'middle','iteration_axis')
text(500,637,'Converged geometry → frequency check',33,T,True,'middle','converged_geometry')
arrow(500,655,500,685,N,3,10)
# Hessian processing and two distinct results of vibrational calculations.
text(500,729,'Harmonic vibrational analysis',38,N,True,'middle','vibration_heading')
boxes=[(60,252,['Hessian','Energy curvature']),(370,270,['Mass-weighting','+ diagonalization']),(698,242,['Normal modes','+ frequencies'])]
for i,(x,w,ls) in enumerate(boxes):
 rect(x,757,w,105,'#E6EFED',None,13,'frequency_step')
 text(x+w/2,798,ls[0],29,T,True,'middle','frequency_step_label');text(x+w/2,839,ls[1],27,N,False,'middle','frequency_step_detail')
 if i<len(boxes)-1:arrow(x+w+9,808,boxes[i+1][0]-9,808,N,2.7,9)
# Frequency analysis yields both minimum verification and thermal quantities.
line(820,862,820,884,N,2);line(280,884,820,884,N,2);arrow(280,884,280,905,N,2,7);arrow(720,884,720,905,N,2,7)
rect(60,913,425,106,'#E5F2EC',None,13,'minimum_verification')
text(272,951,'No imaginary frequencies',29,T,True,'middle','no_imaginary');text(272,995,'Local minimum',34,N,True,'middle','local_minimum')
rect(515,913,425,106,'#F9EFDB',None,13,'thermal_quantities')
text(727,951,'ZPVE + thermal corrections',27,G,True,'middle','thermal_corrections');text(727,995,'H and G at temperature T',28,N,True,'middle','enthalpy_free_energy')
line(55,1041,945,1041,'#CFDADC',3)
# Method labels are separate from the principle diagram.
rect(60,1065,880,105,'#EEF4F2',None,12,'functionals_group')
text(500,1101,'Representative DFT functionals',29,T,True,'middle');text(500,1146,'B3LYP • PBE0 • M06-2X • ωB97X-D',33,N,True,'middle')
rect(60,1190,365,126,'#F4F0F8',None,12,'dispersion_group')
text(242,1227,'Dispersion correction',28,P,True,'middle');text(242,1280,'D3 / D4',36,N,True,'middle')
rect(445,1190,495,126,'#F8F3E9',None,12,'basis_group')
text(692,1227,'Representative basis sets',28,G,True,'middle');text(692,1264,'Double-ζ: 6-31G(d) / def2-SVP',26,N,False,'middle');text(692,1301,'Triple-ζ: 6-311G(d,p) / def2-TZVP',26,N,False,'middle')
text(500,1355,'Diffuse functions for ions • Solvent matched to experiment',26,GRAY,False,'middle','system_specific_choices')
text(500,1391,'Schematic convergence; translation/rotation zero modes are excluded.',24,GRAY,False,'middle','frequency_caveat')
# Export all formats from the SAME scene graph.
pdfmetrics.registerFont(TTFont('ArialGA','/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf'));pdfmetrics.registerFont(TTFont('ArialGABold','/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf'))
pdfmetrics.registerFont(TTFont('DejaVuGA','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'));pdfmetrics.registerFont(TTFont('DejaVuGABold','/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'))
c=canvas.Canvas(str(O/'Geometry_vibration_panel_preview.pdf'),pagesize=(W,H));c.setFillColor('white');c.rect(0,0,W,H,fill=1,stroke=0)
parts=[f'<svg xmlns="http://www.w3.org/2000/svg" width="2000" height="2840" viewBox="0 0 {W} {H}"><title>Editable ensemble-centered ECD/VCD graphical abstract</title><desc>Original molecule-independent conceptual vector diagram. All landscapes and spectra are schematic; no molecular structures or embedded raster images.</desc><rect width="1000" height="1420" fill="white"/>']
r=Presentation();r.slide_width=Inches(W/100);r.slide_height=Inches(H/100);s=r.slides.add_slide(r.slide_layouts[6]);s.background.fill.solid();s.background.fill.fore_color.rgb=RGBColor(255,255,255)

def fillline(sh,fill=None,col=None,width=1.5,dash=False):
 if fill:sh.fill.solid();sh.fill.fore_color.rgb=RGBColor.from_string('FFFFFF' if fill=='white' else fill.lstrip('#'))
 else:sh.fill.background()
 if col:sh.line.color.rgb=RGBColor.from_string(col.lstrip('#'));sh.line.width=Pt(width*.72)
 else:sh.line.fill.background()
 if dash:sh.line.dash_style=MSO_LINE_DASH_STYLE.DASH
for i,a in enumerate(scene):
 kind=a['kind'];name=f'{i:03d}_'+a['name']
 if kind in ['rect','ellipse']:
  x,y,ww,hh=a['x'],a['y'],a['w'],a['h'];fil=a['fill'];stroke=a.get('stroke');typ=MSO_SHAPE.OVAL if kind=='ellipse' else MSO_SHAPE.ROUNDED_RECTANGLE if a['r'] else MSO_SHAPE.RECTANGLE
  sh=s.shapes.add_shape(typ,Inches(x/100),Inches(y/100),Inches(ww/100),Inches(hh/100));fillline(sh,fil,stroke);sh.name=name
  if kind=='rect':
   if a['r']:sh.adjustments[0]=min(.5,a['r']/min(ww,hh))
   parts.append(f'<rect id="{name}" x="{x}" y="{y}" width="{ww}" height="{hh}" rx="{a["r"]}" fill="{fil}" stroke="{stroke or "none"}" stroke-width="1.5"/>');c.setFillColor(fil);c.setStrokeColor(stroke or fil);c.roundRect(x,H-y-hh,ww,hh,a['r'],stroke=bool(stroke),fill=1)
  else:
   parts.append(f'<ellipse id="{name}" cx="{x+ww/2}" cy="{y+hh/2}" rx="{ww/2}" ry="{hh/2}" fill="{fil}"/>');c.setFillColor(fil);c.ellipse(x,H-y-hh,x+ww,H-y,stroke=0,fill=1)
 elif kind=='text':
  x,y,txt,size=a['x'],a['y'],a['t'],a['size'];fn=('DejaVuGA' if a['font']=='DejaVu Sans' else 'ArialGA')+('Bold' if a['bold'] else '');tw=pdfmetrics.stringWidth(txt,fn,size);align=a['align'];left=x-tw/2-3 if align=='middle' else x-tw-3 if align=='end' else x-2
  # Deliberately size each text box to its content so only the target label is selected.
  sh=s.shapes.add_textbox(Inches(left/100),Inches((y-size*.93)/100),Inches((tw+8)/100),Inches(size*1.35/100));sh.name=name;tf=sh.text_frame;tf.margin_left=tf.margin_right=tf.margin_top=tf.margin_bottom=0;tf.word_wrap=False
  pp=tf.paragraphs[0];pp.text=txt;pp.font.name=a['font'];pp.font.size=Pt(size*.72);pp.font.bold=a['bold'];pp.font.color.rgb=RGBColor.from_string('FFFFFF' if a['col']=='white' else a['col'].lstrip('#'));pp.space_after=Pt(0);pp.line_spacing=1
  pp.alignment=PP_ALIGN.CENTER if align=='middle' else PP_ALIGN.RIGHT if align=='end' else PP_ALIGN.LEFT
  parts.append(f'<text id="{name}" x="{x}" y="{y}" fill="{a["col"]}" font-family="{a["font"]},sans-serif" font-size="{size}" font-weight="{700 if a["bold"] else 400}" text-anchor="{align}">{escape(txt)}</text>');c.setFillColor(a['col']);c.setFont(fn,size);{'start':c.drawString,'middle':c.drawCentredString,'end':c.drawRightString}[align](x,H-y,txt)
 else:
  pts=a['pts'];path='M '+' L '.join(f'{x:.3f},{y:.3f}' for x,y in pts)+(' Z' if a['closed'] else '');parts.append(f'<path id="{name}" d="{path}" fill="{a["fill"] or "none"}" stroke="{a["col"] or "none"}" stroke-width="{a["width"]}"'+(' stroke-dasharray="7 5"' if a['dash'] else '')+'/>')
  p=c.beginPath();p.moveTo(pts[0][0],H-pts[0][1]);[p.lineTo(x,H-y) for x,y in pts[1:]]
  if a['closed']:p.close()
  c.setFillColor(a['fill'] or 'white');c.setStrokeColor(a['col'] or 'white');c.setLineWidth(a['width']);c.setDash([7,5] if a['dash'] else []);c.drawPath(p,fill=bool(a['fill']),stroke=bool(a['col']) and a['width']>0);c.setDash([])
  builder=s.shapes.build_freeform(pts[0][0],pts[0][1],scale=9144);builder.add_line_segments(pts[1:],close=a['closed']);sh=builder.convert_to_shape();sh.name=name;fillline(sh,a['fill'],a['col'] if a['width'] else None,a['width'],a['dash'])
c.showPage();c.save();parts.append('</svg>');(O/'Geometry_vibration_panel.svg').write_text('\n'.join(parts));(O/'editable_scene.json').write_text(json.dumps(scene,ensure_ascii=False,indent=2))
s.notes_slide.notes_text_frame.text='Original standalone panel matching the users portrait conformational-search panel, based only on the pasted manuscript sections2.2.1 and2.2.2. Schematic energy and gradient-norm convergence plots illustrate iterative geometry optimization, with no potential contour map, which must be checked through harmonic vibrational analysis. Hessian is mass-weighted and diagonalized to obtain normal modes/frequencies. Excluding translational and rotational zero modes, absence of imaginary frequencies supports a local minimum, not a global minimum. Frequencies also provide ZPVE/thermal corrections for H and G. Representative DFT functionals, basis sets, dispersion corrections, diffuse functions for ions and experimental-solvent matching are stated as text labels. No molecule-specific structure or calculation dataset; no missing Unicode subscript formula is required. No method is claimed universally optimal. SVG uses the standard2000 SVG namespace; native PPT labels are editable.'
from pptx.oxml.xmlchemy import OxmlElement
for obj in s.shapes:
 for ef in obj._element.xpath('.//a:effectRef'):ef.set('idx','0')
 sppr=obj._element.find('{http://schemas.openxmlformats.org/presentationml/2006/main}spPr')
 if sppr is not None:sppr.append(OxmlElement('a:effectLst'))
r.save(O/'Geometry_vibration_panel.pptx')
pdf=fitz.open(O/'Geometry_vibration_panel_preview.pdf');page=pdf[0];page.get_pixmap(matrix=fitz.Matrix(2,2),alpha=False).save(O/'Geometry_vibration_panel_2000x2840.png');page.get_pixmap(matrix=fitz.Matrix(.5,.5),alpha=False).save(O/'Geometry_vibration_panel_preview.png')

print('Exported',len(s.shapes),'native objects')
