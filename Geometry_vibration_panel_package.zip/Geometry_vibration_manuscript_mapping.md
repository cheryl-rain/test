## 版式与内容
按用户修改后的构象搜索图，制作同类竖向浅灰圆角面板。上方显示能量与梯度驱动的结构优化；中部显示Hessian处理、局部极小值核查及热力学输出；下方只列代表性DFT泛函、色散校正、基组及体系依赖条件。不含具体分子或实际计算数据。

## 几何优化：对应原文2.2.1第一段
原文说利用体系能量及其相对核坐标的梯度迭代更新几何结构，寻找PES驻点。图中能量曲线为势能面的二维局部概念截面，箭头与R0、R1、R2…R*表示逐次几何更新。q1、q2为两个抽象几何坐标，等高线表示能量，不对应具体分子；Stationary point: ∇E = 0为根据原文的简写，不是逐字引用。∇E=0仅说明驻点，不能单独保证稳定局部极小值；所以后接振动分析。

## 频率计算：对应原文2.2.2
原文明确Hessian为能量对核坐标的二阶导数，经质量加权与对角化后得到正常振动模式及频率。因此图中用Hessian/Energy curvature→Mass-weighting + diagonalization→Normal modes + frequencies。之后分为两个输出：(1)排除平动、转动零模后，没有虚频支持局部极小值，不是全局最低能构象的证明；(2)ZPVE和给定温度的热力学校正，用于得到H、G，连接后续构象能量及布居。ZPVE为零点振动能。图中不再使用容易出现缺字的ω下标公式。

## 方法名称：对应原文2.2.1第二段
代表泛函：B3LYP、PBE0、M06-2X、ωB97X-D，均来自原文列举。D3/D4是可用于改善色散描述的校正，单独列出，不宣称所有泛函都必须额外叠加它们。双ζ基组代表：6-31G(d)、def2-SVP；三ζ代表：6-311G(d,p)、def2-TZVP。选取原文中的代表基组，未逐一展开案例补充材料中的所有组合。离子体系的弥散函数、与实验匹配的溶剂模型也均来自所贴原文。不同方法会改变相对构象能量和排序，图中Representative不表示通用最优推荐。

## 英文图注
Schematic principles of geometry optimization and vibrational analysis. Iterative energy- and gradient-based refinement locates a stationary structure. The Hessian is mass-weighted and diagonalized to obtain normal modes and harmonic frequencies. After excluding translational and rotational zero modes, the absence of imaginary vibrational frequencies supports assignment as a local minimum. Frequency calculations also provide zero-point vibrational energy and thermal corrections for enthalpy and Gibbs free energy. Representative DFT functionals, dispersion corrections and basis sets are listed separately. The local potential-energy surface and iterative path are conceptual and does not represent a specific molecule or calculation dataset.

## 编辑与格式
Geometry_vibration_panel.svg含26个标准SVG文本对象，可用Illustrator“文件→打开”后用文字工具编辑；所有SVG元素位于正确命名空间http://www.w3.org/2000/svg。PPT含79个原生对象，文字均可作为文本框修改。若通过置入将SVG作为链接对象使用，请先嵌入，或直接打开SVG再复制到目标画板。另有离线文字编辑器Edit_text_offline.html，打开后可点击文字修改并导出SVG。PNG2000×2840；TIFF无损压缩；这是独立竖向局部图，不套用整个图文摘要55:28横向比例，整合时请保持纵横比例。

## 原文和AI说明
本图只依据本轮上传的2.2.1及2.2.2文字整理，不声称本轮重新查阅了原文所有引文。标签是概括性表达，不是全部逐字引句。图形与代码由ChatGPT辅助设计；按稿件已有GenAI披露情况如实说明并由作者审核。