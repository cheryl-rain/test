from pathlib import Path
import math,json,zipfile
from xml.sax.saxutils import escape
import numpy as np
from pptx import Presentation
from pptx.util import Inches,Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN
from pptx.enum.dml import MSO_LINE_DASH_STYLE
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from fontTools.ttLib import TTFont as FT
import fitz
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
O=Path(__file__).resolve().parent;W,H=1000,1420
N='#17364E';T='#07867F';P='#80529D';G='#B98426';GRAY='#647585';BORDER='#C9D5DE';RED='#D74646'
regular='/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf';bold='/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf';cmap=FT(regular).getBestCmap();scene=[]
def rect(x,y,w,h,fill='white',stroke=None,r=12,name='panel'):scene.append(dict(kind='rect',x=x,y=y,w=w,h=h,fill=fill,stroke=stroke,r=r,name=name))
def ell(x,y,r,fill,name='atom'):scene.append(dict(kind='ellipse',x=x-r,y=y-r,w=r*2,h=r*2,fill=fill,name=name))
def text(x,y,t,size=28,col=N,bold=False,align='start',name='text'):
 assert size>=24
 scene.append(dict(kind='text',x=x,y=y,t=t,size=size,col=col,bold=bold,align=align,font='DejaVu Sans' if any(ord(ch) not in cmap for ch in t) else 'Arial',name=name))
def poly(pts,fill=None,col=N,width=2,closed=False,dash=False,name='path'):scene.append(dict(kind='path',pts=[tuple(map(float,p)) for p in pts],col=col,width=width,dash=dash,fill=fill,closed=closed,name=name))
def line(x1,y1,x2,y2,col=N,width=2,dash=False,name='line'):poly([(x1,y1),(x2,y2)],col=col,width=width,dash=dash,name=name)
def arrow(x1,y1,x2,y2,col=N,width=3,head=10,dash=False,name='arrow'):
 dx=x2-x1;dy=y2-y1;l=math.hypot(dx,dy);ux,uy=dx/l,dy/l;bx,by=x2-ux*head,y2-uy*head;line(x1,y1,bx,by,col,width,dash,name+'_shaft');poly([(x2,y2),(bx-uy*head*.58,by+ux*head*.58),(bx+uy*head*.58,by-ux*head*.58)],col,col,0,True,name=name+'_head')
rect(20,15,960,1390,'#F6F9F9',None,30,'portrait_background')
text(500,86,'3  Energies & populations',49,N,True,'middle','title')
text(500,139,'Population calculations for low-energy conformers',29,GRAY,False,'middle','subtitle')
# Route A. Low-energy static conformers and energy-based Boltzmann weights.
rect(52,169,896,617,'white',None,20,'energy_based_route')
text(500,213,'Conformational energies and Boltzmann populations',32,T,True,'middle','static_route_heading')
text(300,251,'Relative Gibbs free energy',24,GRAY,False,'middle','energy_axis_heading')
text(725,251,'Population (Σpᵢ = 1)',25,GRAY,False,'middle','population_axis_heading')
arrow(108,427,108,267,GRAY,2.5,9,name='energy_axis_increasing')
line(585,435,855,435,GRAY,1.5,name='population_baseline')
yvals=[410,366,322,278];wvals=[260,130,65,32.5];colors=[T,P,G,'#8ABBB3']
for i,(y,w,c) in enumerate(zip(yvals,wvals,colors)):
 line(240,y,400,y,c,6,name='relative_G_level')
 text(216,y+11,'C'+str(i+1),32,GRAY,False,'end','energy_level_label')
 rect(585,y-13,w,29,c,None,3,'Boltzmann_weight')
 text(565,y+9,'C'+str(i+1),24,c,True,'end','population_conformer_label')
arrow(424,344,529,344,G,6,15,name='energy_to_population')
text(500,476,'pᵢ = exp(−ΔGᵢ/RT) / Σⱼ exp(−ΔGⱼ/RT)',32,N,True,'middle','normalized_Boltzmann')
text(500,519,'ΔGᵢ = Gᵢ − Gmin;  R: gas constant;  T: absolute temperature',24,GRAY,False,'middle','partition_sum')
text(500,556,'Multilevel option: single-point energy + corrections',26,GRAY,False,'middle','multilevel_option')
# Energy definitions are choices of physical quantity, not sampling or correction methods.
text(280,601,'Electronic energy',28,N,True,'middle','electronic_energy')
text(718,601,'Electronic energy + ZPVE',28,N,True,'middle','ZPVE_corrected_energy')
text(280,639,'Enthalpy (H)',28,N,True,'middle','enthalpy')
text(718,639,'Gibbs free energy (G)',28,N,True,'middle','Gibbs_free_energy')
rect(82,666,836,97,'#EEF3F1',None,13,'thermochemical_treatment')
text(500,700,'Thermodynamic corrections and low-frequency vibrations',27,T,True,'middle','thermochemical_heading')
text(500,735,'RRHO • qRRHO • hindered-rotor model',28,N,False,'middle','thermochemical_models')
text(500,776,'Thermochemical post-processing: Shermo',25,GRAY,False,'middle','Shermo_software')
# The following route is independent of a universally required static Boltzmann pipeline.
text(500,824,'Alternative population / averaging route',26,GRAY,False,'middle','alternative_route_note')
rect(52,843,896,390,'white',None,20,'MD_based_route')
text(500,888,'Conformational populations based on MD sampling',32,P,True,'middle','MD_route_heading')
text(500,929,'Adequate sampling and equilibration',27,GRAY,False,'middle','MD_sampling_condition')
# A symbolic state time series, with occupancy-based bars: no measured MD trajectory.
px,py,pw,ph=133,966,433,112
line(px,py,px,py+ph,GRAY,1.8);line(px,py+ph,px+pw,py+ph,GRAY,1.8)
states=[0,0,1,1,0,0,2,2,1,0,0,0]
def pos(i,st):return (px+pw*i/(len(states)-1),py+ph-19-st*35)
poly([pos(i,s) for i,s in enumerate(states)],col=P,width=2.5,name='symbolic_MD_state_series')
for i,s in enumerate(states):ell(*pos(i,s),3.8,P,'sampled_MD_state')
for st in range(3):text(px-13,py+ph-10-st*35,'C'+str(st+1),24,GRAY,False,'end','state_label')
text(px+pw/2,py+ph+33,'Time',25,GRAY,False,'middle','time_axis')
arrow(586,1025,624,1025,P,2.7,8,name='trajectory_to_weights')
for j in range(3):
 text(670,993+j*36,'C'+str(j+1),24,[T,P,G][j],True,'end','MD_weight_state_label')
 ww=154*states.count(j)/max(states.count(k) for k in range(3));rect(682,975+j*36,ww,21,[T,P,G][j],None,2,'MD_statistical_weight')
text(760,1111,'Statistical weights',25,P,True,'middle','MD_statistical_weights')
text(500,1160,'Direct averaging of snapshot spectra',29,N,True,'middle','snapshot_averaging')
text(500,1206,'or weighting by MD-derived state probabilities',28,N,True,'middle','MD_state_probability_weighting')
# Result connects to spectral simulations rather than assuming either route always superior.
rect(65,1271,870,67,'#E2EFEB',None,15,'weights_output')
text(500,1315,'Conformational weights → spectral averaging',31,T,True,'middle','output')
text(500,1363,'Energy choice and low-frequency treatment affect the resulting weights.',24,GRAY,False,'middle','sensitivity_note')
text(500,1396,'Schematic levels and MD statistics; neither route is universally superior.',24,GRAY,False,'middle','schematic_note')
# Export all formats from the SAME scene graph.
pdfmetrics.registerFont(TTFont('ArialGA','/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf'));pdfmetrics.registerFont(TTFont('ArialGABold','/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf'))
pdfmetrics.registerFont(TTFont('DejaVuGA','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'));pdfmetrics.registerFont(TTFont('DejaVuGABold','/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'))
c=canvas.Canvas(str(O/'Energies_populations_panel_preview.pdf'),pagesize=(W,H));c.setFillColor('white');c.rect(0,0,W,H,fill=1,stroke=0)
parts=[f'<svg xmlns="http://www.w3.org/2000/svg" width="2000" height="2840" viewBox="0 0 {W} {H}"><title>Energies and conformational populations — editable principle diagram</title><desc>Relative Gibbs energies of C1–C4 are mapped to normalized Boltzmann populations. MD state statistics provide an alternative route. All diagrams are schematic; all text is editable.</desc><rect width="1000" height="1420" fill="white"/>']
r=Presentation();r.slide_width=Inches(W/100);r.slide_height=Inches(H/100);s=r.slides.add_slide(r.slide_layouts[6]);s.background.fill.solid();s.background.fill.fore_color.rgb=RGBColor(255,255,255)

def fillline(sh,fill=None,col=None,width=1.5,dash=False):
 if fill:sh.fill.solid();sh.fill.fore_color.rgb=RGBColor.from_string('FFFFFF' if fill=='white' else fill.lstrip('#'))
 else:sh.fill.background()
 if col:sh.line.color.rgb=RGBColor.from_string(col.lstrip('#'));sh.line.width=Pt(width*.72)
 else:sh.line.fill.background()
 if dash:sh.line.dash_style=MSO_LINE_DASH_STYLE.DASH
for i,a in enumerate(scene):
 kind=a['kind'];name=f'{i:03d}_'+a['name']
 if kind in ['rect','ellipse']:
  x,y,ww,hh=a['x'],a['y'],a['w'],a['h'];fil=a['fill'];stroke=a.get('stroke');typ=MSO_SHAPE.OVAL if kind=='ellipse' else MSO_SHAPE.ROUNDED_RECTANGLE if a['r'] else MSO_SHAPE.RECTANGLE
  sh=s.shapes.add_shape(typ,Inches(x/100),Inches(y/100),Inches(ww/100),Inches(hh/100));fillline(sh,fil,stroke);sh.name=name
  if kind=='rect':
   if a['r']:sh.adjustments[0]=min(.5,a['r']/min(ww,hh))
   parts.append(f'<rect id="{name}" x="{x}" y="{y}" width="{ww}" height="{hh}" rx="{a["r"]}" fill="{fil}" stroke="{stroke or "none"}" stroke-width="1.5"/>');c.setFillColor(fil);c.setStrokeColor(stroke or fil);c.roundRect(x,H-y-hh,ww,hh,a['r'],stroke=bool(stroke),fill=1)
  else:
   parts.append(f'<ellipse id="{name}" cx="{x+ww/2}" cy="{y+hh/2}" rx="{ww/2}" ry="{hh/2}" fill="{fil}"/>');c.setFillColor(fil);c.ellipse(x,H-y-hh,x+ww,H-y,stroke=0,fill=1)
 elif kind=='text':
  x,y,txt,size=a['x'],a['y'],a['t'],a['size'];fn=('DejaVuGA' if a['font']=='DejaVu Sans' else 'ArialGA')+('Bold' if a['bold'] else '');tw=pdfmetrics.stringWidth(txt,fn,size);align=a['align'];left=x-tw/2-3 if align=='middle' else x-tw-3 if align=='end' else x-2
  # Deliberately size each text box to its content so only the target label is selected.
  sh=s.shapes.add_textbox(Inches(left/100),Inches((y-size*.93)/100),Inches((tw+8)/100),Inches(size*1.35/100));sh.name=name;tf=sh.text_frame;tf.margin_left=tf.margin_right=tf.margin_top=tf.margin_bottom=0;tf.word_wrap=False
  pp=tf.paragraphs[0];pp.text=txt;pp.font.name=a['font'];pp.font.size=Pt(size*.72);pp.font.bold=a['bold'];pp.font.color.rgb=RGBColor.from_string('FFFFFF' if a['col']=='white' else a['col'].lstrip('#'));pp.space_after=Pt(0);pp.line_spacing=1
  pp.alignment=PP_ALIGN.CENTER if align=='middle' else PP_ALIGN.RIGHT if align=='end' else PP_ALIGN.LEFT
  parts.append(f'<text id="{name}" x="{x}" y="{y}" fill="{a["col"]}" font-family="{a["font"]},sans-serif" font-size="{size}" font-weight="{700 if a["bold"] else 400}" text-anchor="{align}">{escape(txt)}</text>');c.setFillColor(a['col']);c.setFont(fn,size);{'start':c.drawString,'middle':c.drawCentredString,'end':c.drawRightString}[align](x,H-y,txt)
 else:
  pts=a['pts'];path='M '+' L '.join(f'{x:.3f},{y:.3f}' for x,y in pts)+(' Z' if a['closed'] else '');parts.append(f'<path id="{name}" d="{path}" fill="{a["fill"] or "none"}" stroke="{a["col"] or "none"}" stroke-width="{a["width"]}"'+(' stroke-dasharray="7 5"' if a['dash'] else '')+'/>')
  p=c.beginPath();p.moveTo(pts[0][0],H-pts[0][1]);[p.lineTo(x,H-y) for x,y in pts[1:]]
  if a['closed']:p.close()
  c.setFillColor(a['fill'] or 'white');c.setStrokeColor(a['col'] or 'white');c.setLineWidth(a['width']);c.setDash([7,5] if a['dash'] else []);c.drawPath(p,fill=bool(a['fill']),stroke=bool(a['col']) and a['width']>0);c.setDash([])
  builder=s.shapes.build_freeform(pts[0][0],pts[0][1],scale=9144);builder.add_line_segments(pts[1:],close=a['closed']);sh=builder.convert_to_shape();sh.name=name;fillline(sh,a['fill'],a['col'] if a['width'] else None,a['width'],a['dash'])
c.showPage();c.save();parts.append('</svg>');(O/'Energies_populations_panel.svg').write_text('\n'.join(parts));(O/'editable_scene.json').write_text(json.dumps(scene,ensure_ascii=False,indent=2))
s.notes_slide.notes_text_frame.text='Original panel based on the user pasted Section2.3. The energy-based static-conformer Boltzmann route and the adequately equilibrated MD statistical route are alternatives, not sequential mandatory stages. Gibbs-energy formula shown only as an example, with normalization Z. Energy forms are named separately: electronic energy, ZPVE-corrected energy, enthalpy, Gibbs free energy. RRHO, qRRHO and hindered-rotor treatment are distinguished from Shermo post-processing software. MD route includes direct averaging of snapshot spectra or state-probability-based weighting; no universal superiority is claimed. All levels, weights and state trajectories are symbolic illustrations with no molecule-specific data. Formula glyphs and SVG namespace validated; all SVG text and PPT labels editable.'
from pptx.oxml.xmlchemy import OxmlElement
for obj in s.shapes:
 for ef in obj._element.xpath('.//a:effectRef'):ef.set('idx','0')
 sppr=obj._element.find('{http://schemas.openxmlformats.org/presentationml/2006/main}spPr')
 if sppr is not None:sppr.append(OxmlElement('a:effectLst'))
r.save(O/'Energies_populations_panel.pptx')
pdf=fitz.open(O/'Energies_populations_panel_preview.pdf');page=pdf[0];page.get_pixmap(matrix=fitz.Matrix(2,2),alpha=False).save(O/'Energies_populations_panel_2000x2840.png');page.get_pixmap(matrix=fitz.Matrix(.5,.5),alpha=False).save(O/'Energies_populations_panel_preview.png')

print('Exported',len(s.shapes),'native objects')
