## 本版目的
按原稿第2.1节的实际组织重绘，重点从“局部/跨势阱”这一单一概念，转为方法策略、候选构象处理和后续DFT之间的逻辑。不含任何具体分子结构、构象坐标或真实实验/模拟数据。标题和标签是根据正文概括，不是逐字引文。

## 左栏：对应2.1.1
Systematic & stochastic searches：对应原稿对系统搜索与随机搜索的讨论。规则网格代表预设扭转角扫描；散点代表MC候选生成；汇聚/重组符号代表GA全局搜索。正文在同一小节另外讨论GA，图中保留其标签，不把GA等同MC。Torsion scans可对应文献[63]、[73]；MC对应[64,65]及[76–78]；GA对应[66,67]及[79]。网格和散点是概念符号，不构成某种方法优劣的数据。

## 中栏：对应2.1.2
MD & enhanced sampling：原稿说明MD产生连续轨迹，后续可聚类/筛选代表构象；常规MD受可用时间尺度和高能垒限制，REMD和MTD可拓宽构象空间覆盖。概念能量曲线及受限/较广轨迹仅说明原文的能垒与采样问题，不表示真实MD轨迹，也不声称所有常规MD都无法跨势阱。MD对应[68]、[80–83]；增强采样对应[9,69]、[84,85]。

## 右栏：对应2.1.3
Automated hybrid search：正文介绍CREST结合基于RMSD的MTD和GFNn-xTB，并以MD及genetic Z-matrix crossing（GC）辅助探索，再做优化与去重。MTD+MD+GC画在同一框中，表示组合，不把三者误画成严格单向串行步骤。这里的GC是遗传Z矩阵交叉，不等同于左栏一般意义的遗传算法GA。对应[71,72]及[46,86,87]。

## 三栏不是互斥分类
CREST本身使用MD和增强采样，系统与随机搜索也可混用。三栏依原稿小节结构归纳，是互补策略，不宣称数学上相互排斥。图内明确写Complementary routes及sampling strategies can be combined。

## 下方共用路线：对应2.1总述及2.2开头
Candidate ensemble→Preliminary optimization（energy window、deduplication）→Low-energy candidates→DFT refinement。原稿说明先用MMFF、半经验方法或GFNn-xTB低成本评估，再保留能量窗口内的低能候选，进行更高水平DFT精修。该图是代表性路线，并不声称所有软件都以同一顺序执行每项操作。CREST自带优化去重与下方共用路线有所交叠，这是方法内部流程与通用阶段两种表达层级。

## 为何保留MD替代路线
正文2.1.2文献[83]讨论大量MD快照逐一计算ECD后平均，因此不应把所有MD快照都强制画成先经过同一个能量窗口/去重瓶颈。图中单列“Alternative discussed in the review: direct calculations and averaging over MD snapshots”，保留这项原文信息。

## 辅助绘图参考
Higo J, Ikebe J, Kamiya N, Nakamura H. Enhanced and effective conformational sampling of protein molecular systems for their free energy landscapes. Biophysical Reviews. 2012;4:27–44. DOI:10.1007/s12551-011-0063-6。已查看图2和图8，只借鉴能量面/轨迹的科学表达惯例，不复制原图。
Okamoto Y. Protein structure predictions by enhanced conformational sampling methods. Biophysics and Physicobiology. 2019;16:344–366. DOI:10.2142/biophysico.16.0_344。已核实全文及图1、图6图注，未实际查看原图，不作为具体轮廓设计依据。
本版结构组织以用户原稿为主要依据，文献辅助科学图形表达。

## 英文图注
Schematic overview of conformational-search strategies discussed in this review. Systematic and stochastic searches, molecular dynamics and enhanced sampling, and automated hybrid workflows provide complementary routes to candidate ensembles. Preliminary optimization, energy-window screening and duplicate removal can provide representative low-energy candidates for higher-level DFT refinement and subsequent ECD/VCD calculations. Direct calculations and spectral averaging over MD snapshots are also discussed as an alternative route. The diagram is conceptual and does not represent a specific molecular system or numerical comparison of algorithms.

## 中文图注
本文所述构象搜索策略示意。系统与随机搜索、MD与增强采样、自动混合搜索提供互补的候选构象生成途径。通过初步优化、能量窗口筛选和去重，可得到供更高水平DFT精修及后续ECD/VCD计算的代表性低能候选集合。正文另讨论直接对MD快照计算并平均光谱的替代路线。所有图形均为概念示意，不对应具体分子或算法性能比较。

## 文件和编辑
Conformational_search_manuscript.svg保留可编辑文字，可在Inkscape/Illustrator用文字工具修改；PPTX包含102个原生对象，适合PowerPoint编辑；outlined.svg为字体安全版本，文字已转轮廓。PNG4400×2240，55:28比例；另有最小预览1100×560。TIFF为LZW无损压缩备用，PDF为预览。所有格式由同一场景生成，不含嵌入位图。

## AI披露
由ChatGPT辅助组织图文、绘图和编写矢量输出代码；沿用稿件图文摘要的真实GenAI披露，作者审核后确认。不构成新实验或模拟结果。