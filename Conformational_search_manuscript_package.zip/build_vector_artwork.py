from pathlib import Path
import math,json,zipfile
from xml.sax.saxutils import escape
import numpy as np
from pptx import Presentation
from pptx.util import Inches,Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN
from pptx.enum.dml import MSO_LINE_DASH_STYLE
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from fontTools.ttLib import TTFont as FT
import fitz
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
O=Path(__file__).resolve().parent;W,H=2200,1120
N='#17364E';T='#07867F';P='#80529D';G='#B98426';GRAY='#647585';BORDER='#C9D5DE';RED='#D74646'
regular='/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf';bold='/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf';cmap=FT(regular).getBestCmap();scene=[]
def rect(x,y,w,h,fill='white',stroke=None,r=12,name='panel'):scene.append(dict(kind='rect',x=x,y=y,w=w,h=h,fill=fill,stroke=stroke,r=r,name=name))
def ell(x,y,r,fill,name='atom'):scene.append(dict(kind='ellipse',x=x-r,y=y-r,w=r*2,h=r*2,fill=fill,name=name))
def text(x,y,t,size=28,col=N,bold=False,align='start',name='text'):
 assert size>=24
 scene.append(dict(kind='text',x=x,y=y,t=t,size=size,col=col,bold=bold,align=align,font='DejaVu Sans' if any(ord(ch) not in cmap for ch in t) else 'Arial',name=name))
def poly(pts,fill=None,col=N,width=2,closed=False,dash=False,name='path'):scene.append(dict(kind='path',pts=[tuple(map(float,p)) for p in pts],col=col,width=width,dash=dash,fill=fill,closed=closed,name=name))
def line(x1,y1,x2,y2,col=N,width=2,dash=False,name='line'):poly([(x1,y1),(x2,y2)],col=col,width=width,dash=dash,name=name)
def arrow(x1,y1,x2,y2,col=N,width=3,head=10,dash=False,name='arrow'):
 dx=x2-x1;dy=y2-y1;l=math.hypot(dx,dy);ux,uy=dx/l,dy/l;bx,by=x2-ux*head,y2-uy*head;line(x1,y1,bx,by,col,width,dash,name+'_shaft');poly([(x2,y2),(bx-uy*head*.58,by+ux*head*.58),(bx+uy*head*.58,by-ux*head*.58)],col,col,0,True,name=name+'_head')
text(1100,66,'Conformational search: strategies and candidate selection',43,N,True,'middle','title')
text(1100,111,'Complementary routes to a representative low-energy ensemble',29,GRAY,False,'middle','subtitle')
# The three panels correspond to the manuscript's three subsections, not exclusive algorithm classes.
cols=[(60,680,T),(760,680,P),(1460,680,G)]
for x,w,c in cols:rect(x,166,w,458,'#F4F8F8' if c==T else '#F6F3F9' if c==P else '#FCF7ED',None,18,'sampling_route')
# 2.1.1: systematic and stochastic candidates, plus GA-based global search.
x=60;text(x+340,215,'Systematic & stochastic searches',34,T,True,'middle')
# A regular grid is the algorithmic motif for predefined torsion sampling.
gx,gy=96,271;gw,gh=180,119
for i in range(5):line(gx+i*gw/4,gy,gx+i*gw/4,gy+gh,'#BDD2CE',1)
for j in range(4):line(gx,gy+j*gh/3,gx+gw,gy+j*gh/3,'#BDD2CE',1)
for i in range(5):
 for j in range(4):ell(gx+i*gw/4,gy+j*gh/3,3.7,T,'systematic_grid_point')
text(320,303,'Systematic torsion scans',29,N,True);text(320,348,'Predefined sampling',26,GRAY)
# Random candidates and a selection/recombination motif are kept visually separate.
pts=[(112,459),(145,447),(162,488),(194,454),(216,495),(254,468),(126,500)]
for xx,yy in pts:ell(xx,yy,4,T,'stochastic_candidate')
line(124,530,179,555,T,1.8);line(234,530,179,555,T,1.8);ell(124,530,5,T);ell(234,530,5,T);ell(179,555,5,G)
text(320,469,'MC sampling',29,N,True);text(320,523,'GA-based global search',29,N,True)
text(x+340,596,'Generate diverse candidates',27,T,True,'middle')
# 2.1.2: one conceptual energy profile illustrates barriers and different coverage, not measured performance.
x=760;text(x+340,215,'MD & enhanced sampling',34,P,True,'middle')
px,py,pw,ph=x+71,266,538,170
u=np.linspace(0,1,170);vv=.5-.5*np.cos(6*math.pi*u);pts=[(px+pw*a,py+25+115*b) for a,b in zip(u,vv)]
line(px,py,px,py+ph,GRAY,1.3);line(px,py+ph,px+pw,py+ph,GRAY,1.3);poly(pts,col='#A7B9BC',width=2.3,name='generic_barrier_landscape')
# Restricted and wider traces illustrate the manuscript's sampling-barrier discussion.
poly([(px+45+i*1.0,py+120+14*math.sin(i*.12)) for i in range(62)],col=P,width=3,dash=True,name='restricted_sampling')
track=[(px+30+i*3.0,py+20+55*(.5-.5*math.cos(i*.11))+35*math.sin(i*.035)) for i in range(158)];poly(track,col=T,width=2.8,name='barrier_crossing_sampling');arrow(*track[99],*track[104],T,2.3,8)
text(px-12,py+9,'E',24,GRAY,False,'end')
text(x+340,490,'MD • REMD • MTD',31,P,True,'middle');text(x+340,540,'Broaden conformational coverage',27,N,False,'middle');text(x+340,596,'Trajectories → candidate snapshots',27,P,True,'middle')
# 2.1.3: a hybrid wrapper, not a sequential MTD->MD->GC claim.
x=1460;text(x+340,215,'Automated hybrid search',34,G,True,'middle');text(x+340,293,'CREST',42,N,True,'middle');text(x+340,339,'GFNn-xTB',29,G,True,'middle')
rect(x+63,375,554,64,'white',None,10,'CREST_combined_components');text(x+340,418,'MTD  +  MD  +  GC',31,N,True,'middle')
text(x+340,482,'Geometry optimization',28,N,False,'middle');text(x+340,532,'Duplicate removal',28,N,False,'middle');text(x+340,596,'Automated candidate ensemble',27,G,True,'middle')
# Uncluttered converging connections.
for x,w,c in cols:line(x+w/2,624,x+w/2,656,c,2.4);line(x+w/2,656,290,656,c,2.4)
arrow(290,656,290,696,N,2.8,10)
# Representative common route: screening then higher-level refinement.
steps=[(60,460,'Candidate ensemble','Generated by search / sampling'),(575,500,'Preliminary optimization','Energy window • deduplication'),(1130,470,'Low-energy candidates','Representative local minima'),(1655,485,'DFT refinement','For subsequent ECD / VCD')]
for i,(xx,ww,tt,sub) in enumerate(steps):
 rect(xx,713,ww,126,'#E8F1EF' if i<3 else '#FFF0D2',None,14,'candidate_processing_stage')
 text(xx+ww/2,757,tt,29,N,True,'middle');text(xx+ww/2,806,sub,24,GRAY,False,'middle')
 if i<3:arrow(xx+ww+7,775,steps[i+1][0]-8,775,N,2.6,9)
# Model choices are subordinate to workflow, not one universal force field for all methods.
text(1100,895,'Low-cost evaluation: MMFF / semiempirical methods / GFNn-xTB',29,N,True,'middle')
rect(145,938,1910,70,'#F1F4F7',None,12,'alternative_MD_route')
text(1100,983,'Alternative discussed in the review: direct calculations and averaging over MD snapshots',27,GRAY,False,'middle')
text(1100,1073,'Schematic routes; sampling strategies can be combined. No specific molecular structure or simulation dataset.',24,GRAY,False,'middle','disclaimer')
# Export all formats from the SAME scene graph.
pdfmetrics.registerFont(TTFont('ArialGA','/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf'));pdfmetrics.registerFont(TTFont('ArialGABold','/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf'))
pdfmetrics.registerFont(TTFont('DejaVuGA','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'));pdfmetrics.registerFont(TTFont('DejaVuGABold','/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'))
c=canvas.Canvas(str(O/'Conformational_search_manuscript_preview.pdf'),pagesize=(W,H));c.setFillColor('white');c.rect(0,0,W,H,fill=1,stroke=0)
parts=[f'<svg xmlns="http://www.w3.org/2240/svg" width="4400" height="2240" viewBox="0 0 {W} {H}"><title>Editable ensemble-centered ECD/VCD graphical abstract</title><desc>Original molecule-independent conceptual vector diagram. All landscapes and spectra are schematic; no molecular structures or embedded raster images.</desc><rect width="2200" height="1120" fill="white"/>']
r=Presentation();r.slide_width=Inches(W/100);r.slide_height=Inches(H/100);s=r.slides.add_slide(r.slide_layouts[6]);s.background.fill.solid();s.background.fill.fore_color.rgb=RGBColor(255,255,255)

def fillline(sh,fill=None,col=None,width=1.5,dash=False):
 if fill:sh.fill.solid();sh.fill.fore_color.rgb=RGBColor.from_string('FFFFFF' if fill=='white' else fill.lstrip('#'))
 else:sh.fill.background()
 if col:sh.line.color.rgb=RGBColor.from_string(col.lstrip('#'));sh.line.width=Pt(width*.72)
 else:sh.line.fill.background()
 if dash:sh.line.dash_style=MSO_LINE_DASH_STYLE.DASH
for i,a in enumerate(scene):
 kind=a['kind'];name=f'{i:03d}_'+a['name']
 if kind in ['rect','ellipse']:
  x,y,ww,hh=a['x'],a['y'],a['w'],a['h'];fil=a['fill'];stroke=a.get('stroke');typ=MSO_SHAPE.OVAL if kind=='ellipse' else MSO_SHAPE.ROUNDED_RECTANGLE if a['r'] else MSO_SHAPE.RECTANGLE
  sh=s.shapes.add_shape(typ,Inches(x/100),Inches(y/100),Inches(ww/100),Inches(hh/100));fillline(sh,fil,stroke);sh.name=name
  if kind=='rect':
   if a['r']:sh.adjustments[0]=min(.5,a['r']/min(ww,hh))
   parts.append(f'<rect id="{name}" x="{x}" y="{y}" width="{ww}" height="{hh}" rx="{a["r"]}" fill="{fil}" stroke="{stroke or "none"}" stroke-width="1.5"/>');c.setFillColor(fil);c.setStrokeColor(stroke or fil);c.roundRect(x,H-y-hh,ww,hh,a['r'],stroke=bool(stroke),fill=1)
  else:
   parts.append(f'<ellipse id="{name}" cx="{x+ww/2}" cy="{y+hh/2}" rx="{ww/2}" ry="{hh/2}" fill="{fil}"/>');c.setFillColor(fil);c.ellipse(x,H-y-hh,x+ww,H-y,stroke=0,fill=1)
 elif kind=='text':
  x,y,txt,size=a['x'],a['y'],a['t'],a['size'];fn=('DejaVuGA' if a['font']=='DejaVu Sans' else 'ArialGA')+('Bold' if a['bold'] else '');tw=pdfmetrics.stringWidth(txt,fn,size);align=a['align'];left=x-tw/2-3 if align=='middle' else x-tw-3 if align=='end' else x-2
  # Deliberately size each text box to its content so only the target label is selected.
  sh=s.shapes.add_textbox(Inches(left/100),Inches((y-size*.93)/100),Inches((tw+8)/100),Inches(size*1.35/100));sh.name=name;tf=sh.text_frame;tf.margin_left=tf.margin_right=tf.margin_top=tf.margin_bottom=0;tf.word_wrap=False
  pp=tf.paragraphs[0];pp.text=txt;pp.font.name=a['font'];pp.font.size=Pt(size*.72);pp.font.bold=a['bold'];pp.font.color.rgb=RGBColor.from_string('FFFFFF' if a['col']=='white' else a['col'].lstrip('#'));pp.space_after=Pt(0);pp.line_spacing=1
  pp.alignment=PP_ALIGN.CENTER if align=='middle' else PP_ALIGN.RIGHT if align=='end' else PP_ALIGN.LEFT
  parts.append(f'<text id="{name}" x="{x}" y="{y}" fill="{a["col"]}" font-family="{a["font"]},sans-serif" font-size="{size}" font-weight="{700 if a["bold"] else 400}" text-anchor="{align}">{escape(txt)}</text>');c.setFillColor(a['col']);c.setFont(fn,size);{'start':c.drawString,'middle':c.drawCentredString,'end':c.drawRightString}[align](x,H-y,txt)
 else:
  pts=a['pts'];path='M '+' L '.join(f'{x:.3f},{y:.3f}' for x,y in pts)+(' Z' if a['closed'] else '');parts.append(f'<path id="{name}" d="{path}" fill="{a["fill"] or "none"}" stroke="{a["col"] or "none"}" stroke-width="{a["width"]}"'+(' stroke-dasharray="7 5"' if a['dash'] else '')+'/>')
  p=c.beginPath();p.moveTo(pts[0][0],H-pts[0][1]);[p.lineTo(x,H-y) for x,y in pts[1:]]
  if a['closed']:p.close()
  c.setFillColor(a['fill'] or 'white');c.setStrokeColor(a['col'] or 'white');c.setLineWidth(a['width']);c.setDash([7,5] if a['dash'] else []);c.drawPath(p,fill=bool(a['fill']),stroke=bool(a['col']) and a['width']>0);c.setDash([])
  builder=s.shapes.build_freeform(pts[0][0],pts[0][1],scale=9144);builder.add_line_segments(pts[1:],close=a['closed']);sh=builder.convert_to_shape();sh.name=name;fillline(sh,a['fill'],a['col'] if a['width'] else None,a['width'],a['dash'])
c.showPage();c.save();parts.append('</svg>');(O/'Conformational_search_manuscript.svg').write_text('\n'.join(parts));(O/'editable_scene.json').write_text(json.dumps(scene,ensure_ascii=False,indent=2))
s.notes_slide.notes_text_frame.text='Original manuscript-aligned schematic for Section2.1 of pharmaceuticals-4710854. Three parallel panels follow subsections2.1.1 systematic/stochastic searches with GA global search,2.1.2 MD and enhanced sampling, and2.1.3 CREST automated hybrid search. They overlap and are complementary strategies, not mutually exclusive classes. CREST combines RMSD-biased MTD/GFNn-xTB with MD and genetic Z-matrix crossing, followed by optimization and duplicate removal; GC is not identical to the general GA label in the first panel. The lower pipeline is a representative candidate-generation, preliminary optimization/screening and DFT-refinement route. Independent MD snapshot spectral calculations are explicitly noted as an alternative, not required to pass a universal screening bottleneck. No molecular structures or new calculation data. Text labels are concise summaries, not verbatim quotations. All illustrations original; no source figure copied. AI-assisted layout and code, authors to review and disclose. SVG text version retains editable text nodes.'
from pptx.oxml.xmlchemy import OxmlElement
for obj in s.shapes:
 for ef in obj._element.xpath('.//a:effectRef'):ef.set('idx','0')
 sppr=obj._element.find('{http://schemas.openxmlformats.org/presentationml/2006/main}spPr')
 if sppr is not None:sppr.append(OxmlElement('a:effectLst'))
r.save(O/'Conformational_search_manuscript.pptx')
pdf=fitz.open(O/'Conformational_search_manuscript_preview.pdf');page=pdf[0];page.get_pixmap(matrix=fitz.Matrix(2,2),alpha=False).save(O/'Conformational_search_manuscript_4400x2240.png');page.get_pixmap(matrix=fitz.Matrix(.5,.5),alpha=False).save(O/'Conformational_search_manuscript_preview.png')

(O/'Conformational_search_manuscript_outlined.svg').write_text(page.get_svg_image(text_as_path=True))
print('Exported',len(s.shapes),'editable objects')
