## 本次设计
图文摘要以通用计算流程为主：Sample→Refine→Populate→Calculate→Compare。每一步使用专业图形表达其含义，减少文字解释，不再将整张图表述为化合物(R)-1的单一计算案例。ECD/VCD是并行性质计算。环境、动力学与新方法在下方作为跨步骤支持。

## 实际查看的设计参考
Duignan TT. The Potential of Neural Network Potentials. ACS Physical Chemistry Au. 2024;4:232–241. DOI:10.1021/acsphyschemau.4c00004. https://doi.org/10.1021/acsphyschemau.4c00004
已通过Europe PMC获取并实际查看摘要图pg4c00004_0003.jpg。其图用量子力学公式、分子与模拟盒、箭头和长度尺度概括Exact quantum mechanics→DFT→MD→Coarse grained→Macroscopic properties。借鉴的是“每种方法对应一种专业视觉符号，并以箭头串联方法关系”的表达；本图并未复制其原图、模拟盒、尺度轴或特定构图。原图不包含在交付包中。

## 已确认存在、但未用于具体视觉借鉴的图文摘要
Westermayr J, Marquetand P. Machine Learning for Electronically Excited States of Molecules. Chemical Reviews. 2021;121:9873–9926. DOI:10.1021/acs.chemrev.0c00749.
Pescitelli G. ECD exciton chirality method today: a modern tool for determining absolute configurations. Chirality. 2022;34:333–363. DOI:10.1002/chir.23393.
开放全文XML分别确认TOC graphic和graphical abstract存在，但图片媒体包接口超时/返回500；本次没有实际查看原图，因此不声称已借鉴其具体图形或排版。

## 图形对应稿件逻辑
第1步：构象集合、扭转采样和概念势能面，对应2.1。第2步：DFT精修、示意位移箭头和局部势阱，对应2.2。第3步：相对构象能量与布居，低能对应较大权重，对应2.3。第4步：ECD/TDDFT电子跃迁及旋光强度，VCD/DFT振动及旋光强度，对应2.4。第5步：展宽、布居加权及实验比较，对应2.5。下方对应溶剂效应、动态采样、大体系和AI辅助方法。

## 结构及谱线的真实含义
分子模型保留真实化学连接及一致构型，作为代表性手性分子的结构示例。为便于复核，其身份记录为(R)-(2-methylphenyl)(phenyl)methanol，SMILES Cc1ccccc1[C@H](O)c1ccccc1，CIP为R。三维构象由RDKit ETKDG/MMFF独立生成，不是DFT结果或文献坐标。其结构身份可对应稿件文献77：Padula D, Pescitelli G. Molecules. 2018;23:128. DOI:10.3390/molecules23010128。这里不使用文献化合物编号作全图案例标签。势能面、能级、布居条、位移箭头和谱线均是原创示意，不是该分子的成套数据，也不声称该文报道了其VCD。图中已移除Calc./Exp.曲线标签，改为Simulated / experimental comparison (schematic)；光谱面板直接标注Illustrative spectra，分子模型标注Representative conformers，标题下标注Schematic computational workflow。附坐标JSON/SDF用于追溯；MMFF能量未用于图中权重条的定量赋值。

## 科学术语和边界
Rₙ/Rₖ分别表示电子跃迁/振动旋光强度；HFF为谐振力场，APT/AAT为原子极性/轴性张量。局部最小值频率判定应排除平移转动零模。Boltzmann公式使用ΔG示例；具体ΔE/ΔH/ΔG及低频处理由计算方案决定。MD采样权重不与静态Boltzmann权重无条件等价。底部激子方法仅标作exciton ECD。光谱比较需结合计算方法和不确定性分析，示意中的相似性不构成构型判定的定量证据。

## 计算流程依据
Li XC, Ferreira D, Ding Y. Determination of Absolute Configuration of Natural Products: Theoretical Calculation of Electronic Circular Dichroism as a Tool. Curr Org Chem. 2010;14:1678-1697. DOI:10.2174/138527210792927717. https://doi.org/10.2174/138527210792927717
全文及相关图注已核实（未复制图或谱数据）。

## 计算流程依据
Pescitelli G, Di Bari L, Berova N. Conformational aspects in the studies of organic compounds by electronic circular dichroism. Chem Soc Rev. 2011;40:4603-4625. DOI:10.1039/c1cs15036g. https://doi.org/10.1039/c1cs15036g
核实摘要和书目信息；未获取全文。

## 计算流程依据
Pescitelli G, Bruhn T. Good Computational Practice in the Assignment of Absolute Configurations by TDDFT Calculations of ECD Spectra. Chirality. 2016;28:466-474. DOI:10.1002/chir.22600. https://doi.org/10.1002/chir.22600
核实摘要和书目信息；未获取全文。

## 计算流程依据
Bloino J, Jähnigen S, Merten C. After 50 Years of Vibrational Circular Dichroism Spectroscopy: Challenges and Opportunities of Increasingly Accurate and Complex Experiments and Computations. J Phys Chem Lett. 2024;15:8813-8828. DOI:10.1021/acs.jpclett.4c01700. https://doi.org/10.1021/acs.jpclett.4c01700
核实摘要和书目信息；未获取全文。

## 计算流程依据
Koenis MAJ, Xia Y, Domingos SR, Visscher L, Buma WJ, Nicu VP. Taming conformational heterogeneity in and with vibrational circular dichroism spectroscopy. Chem Sci. 2019;10:7680-7689. DOI:10.1039/c9sc02866h. https://doi.org/10.1039/c9sc02866h
全文及相关图注已核实（未复制图或谱数据）。

## 计算流程依据
Pracht P, Bohle F, Grimme S. Automated exploration of the low-energy chemical space with fast quantum chemical methods. Phys Chem Chem Phys. 2020;22:7169-7192. DOI:10.1039/c9cp06869d. https://doi.org/10.1039/c9cp06869d
核实摘要和书目信息；未获取全文。

## 英文图注建议
A schematic quantum-chemical workflow connects conformational sampling, geometry refinement and frequency verification, population evaluation, and parallel ECD/VCD property calculations to ensemble-averaged spectra and stereochemical interpretation. Solvation, dynamics and emerging computational approaches support the workflow. Molecular models and plots are schematic illustrations of individual computational steps and do not constitute a molecule-specific experimental or computational dataset.

## 如何编辑与投稿
PPTX含608个原生对象，可直接修改文本、原子、化学键、箭头、曲线及面板；用选择窗格定位对象，曲线可编辑顶点。SVG文本版保留文字；outlined.svg文字转为轮廓以避免字体替换，仍是真正矢量。两种SVG均无位图嵌入。PNG为4400×2240，最小预览1100×560，均保持55:28比例。PDF供预览，TIFF为备用。字体最小24画布单位，在1100×560预览中相当于12像素。投稿前应以期刊最终显示大小复核文字。

## GenAI披露草案
During the preparation of this work, ChatGPT (OpenAI) was used to assist in organizing and designing the graphical abstract, drafting its caption and explanatory material, and generating code for editable vector artwork. An OpenAI image-generation tool was used for an earlier visual draft.
仅在作者实际审核后补充：After using these tools, the authors reviewed and edited the content as needed and take full responsibility for the content of the publication. 按实际情况补充论文其他部分的AI使用情况。