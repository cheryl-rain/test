from pathlib import Path
import math,json,zipfile
from xml.sax.saxutils import escape
import numpy as np
from pptx import Presentation
from pptx.util import Inches,Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN
from pptx.enum.dml import MSO_LINE_DASH_STYLE
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from fontTools.ttLib import TTFont as FT
import fitz
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
O=Path(__file__).resolve().parent;W,H=3300,1680
N='#17364E';T='#07867F';P='#80529D';G='#B98426';GRAY='#647585';BORDER='#C9D5DE';RED='#D74646'
regular='/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf';bold='/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf';cmap=FT(regular).getBestCmap();scene=[]
def rect(x,y,w,h,fill='white',stroke=None,r=12,name='panel'):scene.append(dict(kind='rect',x=x,y=y,w=w,h=h,fill=fill,stroke=stroke,r=r,name=name))
def ell(x,y,r,fill,name='atom'):scene.append(dict(kind='ellipse',x=x-r,y=y-r,w=r*2,h=r*2,fill=fill,name=name))
def text(x,y,t,size=28,col=N,bold=False,align='start',name='text'):
 assert size>=36
 scene.append(dict(kind='text',x=x,y=y,t=t,size=size,col=col,bold=bold,align=align,font='DejaVu Sans' if any(ord(ch) not in cmap for ch in t) else 'Arial',name=name))
def poly(pts,fill=None,col=N,width=2,closed=False,dash=False,name='path'):scene.append(dict(kind='path',pts=[tuple(map(float,p)) for p in pts],col=col,width=width,dash=dash,fill=fill,closed=closed,name=name))
def line(x1,y1,x2,y2,col=N,width=2,dash=False,name='line'):poly([(x1,y1),(x2,y2)],col=col,width=width,dash=dash,name=name)
def arrow(x1,y1,x2,y2,col=N,width=3,head=10,dash=False,name='arrow'):
 dx=x2-x1;dy=y2-y1;l=math.hypot(dx,dy);ux,uy=dx/l,dy/l;bx,by=x2-ux*head,y2-uy*head;line(x1,y1,bx,by,col,width,dash,name+'_shaft');poly([(x2,y2),(bx-uy*head*.58,by+ux*head*.58),(bx+uy*head*.58,by-ux*head*.58)],col,col,0,True,name=name+'_head')
# Schematic spectra: sticks transformed to continuous curves; not molecular calculation outputs.
def spectrum(x,y,ww,hh,col,mode='ecd',compare=False,name='spectrum'):
 line(x,y+hh/2,x+ww,y+hh/2,'#9AAAB6',1.3,name=name+'_zero');line(x,y,x,y+hh,'#9AAAB6',1.3,name=name+'_axis')
 centers=[.19,.39,.66,.83] if mode=='ecd' else [.12,.26,.34,.45,.55,.68,.76,.88];strength=[.9,-.62,.55,-.3] if mode=='ecd' else [.65,-.85,.7,-.42,.8,-.55,.45,-.6];sigma=.06 if mode=='ecd' else .017
 def f(u,shift=0):
  if mode=='ecd':return sum(a*math.exp(-((u-m+shift)/sigma)**2) for a,m in zip(strength,centers))
  return sum(a/(1+((u-m+shift)/sigma)**2) for a,m in zip(strength,centers))
 pts=[(x+ww*i/150,y+hh/2-hh*.36*f(i/150)) for i in range(151)];poly(pts,col=col,width=3.1,name=name+'_weighted')
 if compare:poly([(x+ww*i/150,y+hh/2-hh*.33*f(i/150,.008)) for i in range(151)],col=GRAY,width=2,dash=True,name=name+'_experimental_schematic')
def sticks(x,y,ww,hh,col,mode):
 centers=[.12,.35,.56,.82] if mode=='ecd' else [.1,.2,.32,.44,.52,.66,.75,.88];a=[.75,-.6,.95,-.45] if mode=='ecd' else [.65,-.8,.55,-.45,.9,-.7,.4,-.6];line(x,y+hh/2,x+ww,y+hh/2,'#9AAAB6',1.2)
 for p,v in zip(centers,a):line(x+p*ww,y+hh/2,x+p*ww,y+hh/2-v*hh*.44,col,3,name=mode+'_rotatory_strength_stick')
text(1650,89,'Quantum-chemical workflows for ECD and VCD',66,N,True,'middle','main_title')
text(1650,151,'Principles, representative methods and emerging developments',39,GRAY,False,'middle','subtitle')
xs=[80,720,1360,2000,2640];bw=580
heads=[['1  Conformational','search'],['2  Optimization &','frequencies'],['3  Energies &','populations'],['4  ECD / VCD','properties'],['5  Spectral simulation','& comparison']]
for i,x in enumerate(xs):
 rect(x,204,bw,1040,'#F7F9FA',None,22,'stage_'+str(i+1))
 for j,t in enumerate(heads[i]):text(x+bw/2,256+46*j,t,42,N,True,'middle','stage_'+str(i+1)+'_heading')
 if i<4:arrow(x+bw+5,574,xs[i+1]-7,574,N,4,14,name='workflow_arrow_'+str(i+1))
# 1. Principle: multidimensional exploration -> local minima -> energy/uniqueness filtering.
x=xs[0];px,py,pw,ph=x+52,338,475,275
xx=np.linspace(-3,3,110);yy=np.linspace(-3,3,100);X,Y=np.meshgrid(xx,yy)
Z=.045*(X*X+Y*Y)-2.9*np.exp(-((X+1.4)**2/.95+(Y+1.05)**2/.9))-2.2*np.exp(-((X-1.25)**2/.85+(Y-1.3)**2/.8))-1.9*np.exp(-((X-1.5)**2/.7+(Y+1.2)**2/.75))-.8*np.exp(-((X+1.4)**2/.65+(Y-1.5)**2/.65))
def pos(u,v):return (px+(u+3)/6*pw,py+(3-v)/6*ph)
fig,ax=plt.subplots();co=ax.contour(X,Y,Z,levels=[-2.5,-1.9,-1.4,-.9,-.5,-.2,.15])
for segs in co.allsegs:
 for seg in segs:
  if len(seg)>2:poly([pos(u,v) for u,v in seg],col='#ABC4BF',width=1.6,name='search_potential_contour')
plt.close(fig);line(px,py,px,py+ph,GRAY,1.6);line(px,py+ph,px+pw,py+ph,GRAY,1.6)
seeds=[(-2.2,-1.6),(-.6,-.3),(-1.9,2.1),(.5,1.9),(1.9,1.8),(.7,-.6),(2,-1.8)]
poly([pos(*p) for p in seeds],col='#9DC6BE',width=2,dash=True,name='trial_exploration')
for p,c in zip([seeds[0],seeds[2],seeds[3],seeds[6]],[(-1.4,-1.05),(-1.4,1.5),(1.25,1.3),(1.5,-1.2)]):arrow(*pos(*p),*pos(*c),G,2.5,9,name='local_descent');ell(*pos(*p),4,T,'sampled_configuration')
for c in [(-1.4,-1.05),(1.25,1.3),(1.5,-1.2)]:ell(*pos(*c),7,G,'candidate_minimum')
text(px-25,py+155,'φ₂',36,GRAY,False,'end');text(px+pw/2,py+ph+41,'φ₁',36,GRAY,False,'middle')
# Energy window motif; not another molecule example.
base=747;line(x+110,base,x+110,665,GRAY,1.5)
for dx,yy in [(140,732),(230,710),(320,680),(410,653)]:line(x+dx,yy,x+dx+55,yy,T if yy>667 else GRAY,3)
line(x+125,667,x+500,667,G,1.8,True)
text(x+bw/2,807,'Explore → minimize → filter',36,T,True,'middle')
# 2. Gradient-based relaxation, followed by mass-weighted Hessian frequencies.
x=xs[1];px,py=x+78,346;pw,ph=425,220
line(px,py,px,py+ph,GRAY,1.6);line(px,py+ph,px+pw,py+ph,GRAY,1.6)
pts=[(px+pw*i/100,py+18+180*(1-((i-50)/50)**2)) for i in range(101)];poly(pts,col=T,width=3.2,name='local_potential_well')
for j,k in [(12,31),(85,68)]:arrow(*pts[j],*pts[k],G,3,11,name='gradient_descent')
ell(*pts[50],7,G);text(x+bw/2,620,'∇E = 0',45,N,True,'middle','stationary_point')
text(x+bw/2,692,'Mass-weighted Hessian',36,N,False,'middle')
text(x+bw/2,749,'Hmw → ωₖ² > 0',42,T,True,'middle')
text(x+bw/2,807,'Verify local minima',36,T,True,'middle')
# 3. Relative energies and probabilities: lower state -> larger weight.
x=xs[2];ys=[570,507,444,381];wws=[211,132,78,40]
for i,(y,w) in enumerate(zip(ys,wws)):
 line(x+70,y,x+207,y,N,3);text(x+57,y+10,'G'+str(i+1),36,GRAY,False,'end');rect(x+307,y-16,w,32,[T,P,G,'#8ABEB6'][i],None,3,'population_'+str(i+1))
arrow(x+221,474,x+285,474,G,3,10)
text(x+bw/2,645,'pᵢ ∝ exp(−ΔGᵢ/RT)',39,N,True,'middle')
text(x+bw/2,705,'Thermochemical corrections',36,N,False,'middle')
text(x+bw/2,758,'or sampled MD statistics',36,GRAY,False,'middle')
text(x+bw/2,807,'Determine ensemble weights',36,T,True,'middle')
# 4. Parallel physical properties; electronic excitations are not universally HOMO-LUMO.
x=xs[3];rect(x+20,330,bw-40,220,'#E4F2EE',None,14,'ECD_physics');text(x+42,379,'ECD',44,T,True)
line(x+61,510,x+192,510,N,2.5);line(x+61,419,x+192,419,N,2.5);arrow(x+126,503,x+126,426,T,3.5,11);text(x+202,433,'Sₙ',36,GRAY);text(x+202,521,'S₀',36,GRAY)
sticks(x+302,403,216,119,T,'ecd');text(x+360,384,'ΔEₙ , Rₙ',36,N,True,'middle')
rect(x+20,570,bw-40,220,'#EEE8F5',None,14,'VCD_physics');text(x+42,619,'VCD',44,P,True)
line(x+57,697,x+227,697,'#B7AABD',1.3,True);poly([(x+57+i*1.7,697-34*math.sin(i*math.pi*2/100)) for i in range(101)],col=P,width=3,name='normal_coordinate_motion');arrow(x+104,642,x+179,642,P,2.5,9);text(x+143,769,'qₖ',36,P,False,'middle')
sticks(x+302,647,216,118,P,'vcd');text(x+389,624,'ωₖ , Rₖ',36,N,True,'middle')
# 5. Broadening, correction, weighting and experimental comparison.
x=xs[4];text(x+bw/2,370,'S̄ = Σᵢ pᵢ Sᵢ',47,N,True,'middle');text(x+40,426,'ECD',38,T,True)
spectrum(x+70,444,445,108,T,'ecd',True,'ECD_illustrative');text(x+515,598,'λ',36,GRAY,False,'end')
text(x+40,642,'VCD',38,P,True);spectrum(x+70,660,445,106,P,'vcd',True,'VCD_illustrative');text(x+515,813,'ν̃',36,GRAY,False,'end')
# Methods are text labels only, visually separate from principles.
for x in xs:line(x+25,851,x+bw-25,851,'#D0DADC',1.4)
methodrows=[
 [('Systematic / stochastic',T,True),('torsion scans • MC • GA',N,False),('MD / enhanced sampling',T,True),('MD • REMD • MTD',N,False),('Automated hybrid: CREST',T,True),('GFNn-xTB; MTD / MD / GC',N,False)],
 [('DFT geometry optimization',T,True),('B3LYP • PBE0 • M06-2X',N,False),('ωB97X-D • D3 / D4',N,False),('Harmonic frequency analysis',T,True),('6-31G(d) • def2-SVP',N,False),('6-311G(d,p) • def2-TZVP',N,False)],
 [('ΔE / ΔE₀ / ΔH / ΔG',N,True),('RRHO • qRRHO',N,False),('Hindered rotors • Shermo',N,False),('Boltzmann populations',T,True),('Equilibrated MD statistics',T,True),('Low-frequency treatment',N,False)],
 [('ECD: LR-TDDFT / RT-TDDFT',T,True),('CC2 • EOM-CCSD • ADC',N,False),('CASSCF / CASPT2',N,False),('VCD: harmonic DFT',P,True),('HFF + APT + AAT',N,False),('MP2 • VPT2 / GVPT2',N,False),('AIMD time correlations',N,False)],
 [('Gaussian / Lorentzian',N,True),('ECD: energy / wavelength shift',N,False),('VCD: frequency scaling',N,False),('Boltzmann-weighted averaging',T,True),('MD snapshot averaging',T,True),('Configuration / conformation',T,True)]]
for x,rows in zip(xs,methodrows):
 for j,(t,c,b) in enumerate(rows):text(x+bw/2,916+j*44,t,36,c,b,'middle','method_label')
# Environment effects are cross-cutting; emerging approaches are complementary.
rect(80,1280,3140,77,'#E3EFED',None,19,'solvation_strip');text(1650,1330,'Solvent models: PCM / COSMO / SMD • explicit–implicit • QM/MM • RISM-SCF-cSED',41,N,True,'middle')
rect(160,1390,2980,68,'#FFF0D0',None,18,'key_message');text(1650,1438,'Sampling and population reliability shape the final spectrum',46,N,True,'middle')
rect(80,1490,1530,125,'white',BORDER,17,'exciton_extension');text(845,1537,'Exciton ECD for larger systems',42,P,True,'middle');text(845,1590,'Local chromophore excitations + intersite coupling',36,N,False,'middle')
rect(1660,1490,1560,125,'white',BORDER,17,'AI_extension');text(2440,1537,'AI-assisted analysis and prediction',42,T,True,'middle');text(2440,1590,'Spectra analysis • GA populations • ML spectra',36,N,False,'middle')
text(1650,1660,'Static-minimum route shown; direct MD snapshot averaging is an alternative. All plots are schematic.',36,GRAY,False,'middle','schematic_note')
# Export all formats from the SAME scene graph.
pdfmetrics.registerFont(TTFont('ArialGA','/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf'));pdfmetrics.registerFont(TTFont('ArialGABold','/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf'))
pdfmetrics.registerFont(TTFont('DejaVuGA','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'));pdfmetrics.registerFont(TTFont('DejaVuGABold','/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'))
c=canvas.Canvas(str(O/'Full_ECD_VCD_GA_preview.pdf'),pagesize=(W,H));c.setFillColor('white');c.rect(0,0,W,H,fill=1,stroke=0)
parts=[f'<svg xmlns="http://www.w3.org/2000/svg" width="6600" height="3360" viewBox="0 0 {W} {H}"><title>Editable ensemble-centered ECD/VCD graphical abstract</title><desc>Original molecule-independent conceptual vector diagram. All landscapes and spectra are schematic; no molecular structures or embedded raster images.</desc><rect width="3300" height="1680" fill="white"/>']
r=Presentation();r.slide_width=Inches(W/100);r.slide_height=Inches(H/100);s=r.slides.add_slide(r.slide_layouts[6]);s.background.fill.solid();s.background.fill.fore_color.rgb=RGBColor(255,255,255)

def fillline(sh,fill=None,col=None,width=1.5,dash=False):
 if fill:sh.fill.solid();sh.fill.fore_color.rgb=RGBColor.from_string('FFFFFF' if fill=='white' else fill.lstrip('#'))
 else:sh.fill.background()
 if col:sh.line.color.rgb=RGBColor.from_string(col.lstrip('#'));sh.line.width=Pt(width*.72)
 else:sh.line.fill.background()
 if dash:sh.line.dash_style=MSO_LINE_DASH_STYLE.DASH
for i,a in enumerate(scene):
 kind=a['kind'];name=f'{i:03d}_'+a['name']
 if kind in ['rect','ellipse']:
  x,y,ww,hh=a['x'],a['y'],a['w'],a['h'];fil=a['fill'];stroke=a.get('stroke');typ=MSO_SHAPE.OVAL if kind=='ellipse' else MSO_SHAPE.ROUNDED_RECTANGLE if a['r'] else MSO_SHAPE.RECTANGLE
  sh=s.shapes.add_shape(typ,Inches(x/100),Inches(y/100),Inches(ww/100),Inches(hh/100));fillline(sh,fil,stroke);sh.name=name
  if kind=='rect':
   if a['r']:sh.adjustments[0]=min(.5,a['r']/min(ww,hh))
   parts.append(f'<rect id="{name}" x="{x}" y="{y}" width="{ww}" height="{hh}" rx="{a["r"]}" fill="{fil}" stroke="{stroke or "none"}" stroke-width="1.5"/>');c.setFillColor(fil);c.setStrokeColor(stroke or fil);c.roundRect(x,H-y-hh,ww,hh,a['r'],stroke=bool(stroke),fill=1)
  else:
   parts.append(f'<ellipse id="{name}" cx="{x+ww/2}" cy="{y+hh/2}" rx="{ww/2}" ry="{hh/2}" fill="{fil}"/>');c.setFillColor(fil);c.ellipse(x,H-y-hh,x+ww,H-y,stroke=0,fill=1)
 elif kind=='text':
  x,y,txt,size=a['x'],a['y'],a['t'],a['size'];fn=('DejaVuGA' if a['font']=='DejaVu Sans' else 'ArialGA')+('Bold' if a['bold'] else '');tw=pdfmetrics.stringWidth(txt,fn,size);align=a['align'];left=x-tw/2-3 if align=='middle' else x-tw-3 if align=='end' else x-2
  # Deliberately size each text box to its content so only the target label is selected.
  sh=s.shapes.add_textbox(Inches(left/100),Inches((y-size*.93)/100),Inches((tw+8)/100),Inches(size*1.35/100));sh.name=name;tf=sh.text_frame;tf.margin_left=tf.margin_right=tf.margin_top=tf.margin_bottom=0;tf.word_wrap=False
  pp=tf.paragraphs[0];pp.text=txt;pp.font.name=a['font'];pp.font.size=Pt(size*.72);pp.font.bold=a['bold'];pp.font.color.rgb=RGBColor.from_string('FFFFFF' if a['col']=='white' else a['col'].lstrip('#'));pp.space_after=Pt(0);pp.line_spacing=1
  pp.alignment=PP_ALIGN.CENTER if align=='middle' else PP_ALIGN.RIGHT if align=='end' else PP_ALIGN.LEFT
  parts.append(f'<text id="{name}" x="{x}" y="{y}" fill="{a["col"]}" font-family="{a["font"]},sans-serif" font-size="{size}" font-weight="{700 if a["bold"] else 400}" text-anchor="{align}">{escape(txt)}</text>');c.setFillColor(a['col']);c.setFont(fn,size);{'start':c.drawString,'middle':c.drawCentredString,'end':c.drawRightString}[align](x,H-y,txt)
 else:
  pts=a['pts'];path='M '+' L '.join(f'{x:.3f},{y:.3f}' for x,y in pts)+(' Z' if a['closed'] else '');parts.append(f'<path id="{name}" d="{path}" fill="{a["fill"] or "none"}" stroke="{a["col"] or "none"}" stroke-width="{a["width"]}"'+(' stroke-dasharray="7 5"' if a['dash'] else '')+'/>')
  p=c.beginPath();p.moveTo(pts[0][0],H-pts[0][1]);[p.lineTo(x,H-y) for x,y in pts[1:]]
  if a['closed']:p.close()
  c.setFillColor(a['fill'] or 'white');c.setStrokeColor(a['col'] or 'white');c.setLineWidth(a['width']);c.setDash([7,5] if a['dash'] else []);c.drawPath(p,fill=bool(a['fill']),stroke=bool(a['col']) and a['width']>0);c.setDash([])
  builder=s.shapes.build_freeform(pts[0][0],pts[0][1],scale=9144);builder.add_line_segments(pts[1:],close=a['closed']);sh=builder.convert_to_shape();sh.name=name;fillline(sh,a['fill'],a['col'] if a['width'] else None,a['width'],a['dash'])
c.showPage();c.save();parts.append('</svg>');(O/'Full_ECD_VCD_GA.svg').write_text('\n'.join(parts));(O/'editable_scene.json').write_text(json.dumps(scene,ensure_ascii=False,indent=2))
s.notes_slide.notes_text_frame.text='Full manuscript-aligned conceptual graphical abstract. Five linked stages: conformational search, optimization/frequency verification, populations, parallel ECD/VCD properties, broadening/correction/weighting/comparison. All molecular structures are omitted. Methods are text labels, principles are diagrams. Text labels summarize manuscript methods rather than verbatim quotations; choices are representative, not an exhaustive recommended universal protocol. MD-trajectory averaging is an alternative route and not forced to undergo static minimum optimization. Solvent models span computational steps. Exciton models concern ECD; AI applications include spectra analysis, GA-constrained populations and rapid prediction. All curves and symbolic levels are schematic. No newly claimed experimental/quantum data. Primary search figure sources viewed: Confab Figure1, CONFORGE Figures4/6/9, Higo Figures2/8, Bayesian conformer generation Figure1. No source figure artwork copied. SVG retains native text nodes; PPT has native editable textboxes. Offline HTML editor enables clicking and editing SVG labels, then downloading edited SVG. AI-assisted design/code requires truthful disclosure and author review.'
from pptx.oxml.xmlchemy import OxmlElement
for obj in s.shapes:
 for ef in obj._element.xpath('.//a:effectRef'):ef.set('idx','0')
 sppr=obj._element.find('{http://schemas.openxmlformats.org/presentationml/2006/main}spPr')
 if sppr is not None:sppr.append(OxmlElement('a:effectLst'))
r.save(O/'Full_ECD_VCD_GA.pptx')
pdf=fitz.open(O/'Full_ECD_VCD_GA_preview.pdf');page=pdf[0];page.get_pixmap(matrix=fitz.Matrix(2,2),alpha=False).save(O/'Full_ECD_VCD_GA_6600x3360.png');page.get_pixmap(matrix=fitz.Matrix(1/3,1/3),alpha=False).save(O/'Full_ECD_VCD_GA_1100x560_preview.png')

