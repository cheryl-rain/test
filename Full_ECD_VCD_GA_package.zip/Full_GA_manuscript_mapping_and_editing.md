## 完整图的组织
以原稿第2章五个计算环节为主线，各栏上半部画原理，下半部只列代表性方法/处理名称。不含特定分子结构。溶剂为跨步骤条带，激子ECD和AI为第3章发展方向，可靠采样及布居为第4章核心信息。方法列表是从原文选取的代表，不是普遍适用的标准方案，也不穷尽每项基组和软件。图题为新概括标题，不是原文引句。

## 第1栏：2.1构象搜索
以抽象二维扭转势能面、试探构型、局部下降箭头、局部极小值及能量阈值示意探索—最小化—筛选。不是将网格当作系统搜索的完整原理，或将散点当作随机搜索的完整算法。方法名按2.1.1—2.1.3列为：系统扭转扫描、MC、GA；MD、REMD、MTD；CREST与GFNn-xTB及MTD/MD/GC组合。策略有交叠，可组合。GC为genetic Z-matrix crossing，不等同一般GA。能量窗和去重在本图中为筛选原则，图注强调代表性路线。

## 第2栏：2.2优化与频率
原理图为沿能量梯度进入局部势阱、驻点∇E=0，以及质量加权Hessian特征值对应振动频率的核查。Hmw指质量加权Hessian；ωₖ²>0指排除平移/转动零模后的振动模，用于确认局部极小值。方法标签来自原稿：DFT、B3LYP/PBE0/M06-2X/ωB97X-D、D3/D4以及代表双/三ζ基组；不把某个泛函或基组认定为普遍最优。此处没有新分子几何优化数据。

## 第3栏：2.3能量与布居
能级和权重条说明能量差对Boltzmann权重的影响，较低能量对应较大权重，数值仅概念示意。ΔG形式为示例，原文还讨论ΔE、ΔE0（零点能校正）、ΔH、ΔG、RRHO/qRRHO、hindered rotors、Shermo，以及基于充分平衡MD采样的统计权重。MD统计是互补路线，不需要所有采样结构先成为优化极小值；本图底部明确静态极小值流程和直接MD快照平均的区别。

## 第4栏：2.4性质计算
ECD与VCD并列，分别用电子跃迁能级/旋光强度棒谱和抽象正常坐标/振动旋光强度表示。没有画通用HOMO→LUMO假设。ECD方法选取LR-/RT-TDDFT、CC2/EOM-CCSD/ADC、CASSCF/CASPT2；VCD选取谐振DFT及HFF/APT/AAT、MP2、VPT2/GVPT2和AIMD时间相关函数。AIMD相关函数路线并非谐振Hessian路线的后续步骤，而是原文讨论的替代处理。未把两类光谱画成串行计算。

## 第5栏：2.5光谱模拟和平均
以两类示意光谱及ΣpᵢSᵢ表示谱线模拟与构象平均。方法标签分为Gaussian/Lorentzian展宽、ECD能量/波长平移、VCD频率缩放、Boltzmann加权和MD快照平均。曲线无具体峰位数值、没有真实数据图例，不代表某个分子的计算与实验光谱。原稿中比较和校正的具体定义、参数和局限仍需在正文解释。输出目标为构型及构象解释，不能仅凭示意谱相似性保证构型判定正确。

## 跨步骤与发展方向：2.6及第3—4章
PCM/COSMO/SMD、显式—隐式模型、QM/MM和RISM-SCF-cSED来自2.6。下方Exciton ECD for larger systems对应3.1，不扩展宣称为VCD激子方法。AI谱分析、GA布居优化和ML快速光谱预测对应3.2。GA拟合布居需要约束和交叉验证，其拟合改善不自动证明真实布居。Sampling and population reliability shape the final spectrum是根据摘要/结论概括的核心信息，不是原文逐字引用。

## 为何之前SVG看起来不能改文字
此前构象搜索SVG含33个原生text节点，而非全部转轮廓；具体不能编辑的原因取决于打开的软件和导入方式，目前未得到用户软件名称。将SVG直接插入PPT/Word通常作为一个整体图形，不能像文本框直接输入。SVG仍有文字不等于每种软件都将它导入为文字。本次同时提供原生PPT、Inkscape保存版本和独立离线编辑器，避免依赖同一种导入方式。

## 本次可编辑性实测
主SVG分成Vector artwork及Editable text两层，77个text节点、0个image节点。Inkscape打开并另存为普通SVG后，仍保留77个text节点。浏览器实测离线编辑器：点击标题→在输入框修改文字→导出SVG→XML确认77个text节点仍在，且修改内容正确→恢复初始版本，测试通过。PPT所有文字为文本框、所有图形为原生对象，无嵌入图片。未提供文字转轮廓版，避免再次误选。

## 推荐编辑方式
方法A：PowerPoint打开Full_ECD_VCD_GA.pptx，直接点击文字编辑；不要将SVG插入PPT后期待它自动拆成文本框。
方法B：解压文件包，在Chrome/Edge等本地浏览器打开Edit_text_offline.html，点击图中文字或从右侧列表选择，修改内容、字号、颜色后下载修改后的SVG。页面不联网、不上传内容；关闭前需导出，修改不会自动写回原文件。文字变长时可调整字号；页面不做自动换行排版。
方法C：Inkscape打开Full_ECD_VCD_GA_Inkscape.svg，选文字工具（T或F8），点击文字内容；图层面板可选Editable text。数学符号由DejaVu Sans支持，普通字为Arial或兼容字体。SVG两个版本文字均为text，而PDF只作为预览。

## 期刊尺寸
画布3300×1680，比例55:28；PNG6600×3360；最小预览1100×560。最小字号36画布单位，对应最小预览约12像素。TIFF为LZW无损压缩，PDF为同源矢量预览。PNG/SVG在编辑要求的格式列表中；作者仍应以最终投稿缩放检查可读性。

## 英文图注
Schematic quantum-chemical workflows for ECD and VCD calculations. Principle diagrams connect conformational-space exploration and candidate selection, geometry refinement and vibrational verification, energy and population evaluation, parallel chiroptical property calculations, and spectral simulation and comparison. Representative methods and treatments are listed separately beneath each principle. Solvation spans the computational steps, while exciton models and AI-assisted approaches provide complementary developments. The main sequence illustrates a static-minimum workflow; direct calculations and averaging over appropriately sampled MD snapshots provide alternative routes. All diagrams and spectra are conceptual and do not represent a molecule-specific computational or experimental dataset.

## 搜索原理图的实际原图核查
本轮沿用已经实际查看的4篇相关文章7幅原图：Confab图1（10.1186/1758-2946-3-8）；CONFORGE图4/6/9（10.1021/acs.jcim.3c00563）；Higo综述图2/8（10.1007/s12551-011-0063-6）；Bayesian构象生成图1（10.1186/s13321-019-0354-7）。原稿没有Bayesian方法，因此不在方法分类中新增Bayesian。CONFORGE的随机生成包括距离几何，不能把它等同MC。本图提炼共同原理，不复制任何原图像素或路径。

## 其他流程依据及核实层级
Li XC, Ferreira D, Ding Y. Determination of Absolute Configuration of Natural Products: Theoretical Calculation of Electronic Circular Dichroism as a Tool. Curr Org Chem. 2010;14:1678–1697. DOI:10.2174/138527210792927717。全文及相关图注已核实，未复制图片。
Koenis MAJ, et al. Taming conformational heterogeneity in and with vibrational circular dichroism spectroscopy. Chem Sci. 2019;10:7680–7689. DOI:10.1039/c9sc02866h。全文及相关图注已核实，原始研究，不是综述。
Pescitelli G, Di Bari L, Berova N. Conformational aspects in the studies of organic compounds by electronic circular dichroism. Chem Soc Rev. 2011;40:4603–4625. DOI:10.1039/c1cs15036g。仅核实摘要及元数据。
Pescitelli G, Bruhn T. Good Computational Practice in the Assignment of Absolute Configurations by TDDFT Calculations of ECD Spectra. Chirality. 2016;28:466–474. DOI:10.1002/chir.22600。仅核实摘要及元数据。
Bloino J, Jähnigen S, Merten C. After 50 Years of Vibrational Circular Dichroism Spectroscopy: Challenges and Opportunities of Increasingly Accurate and Complex Experiments and Computations. J Phys Chem Lett. 2024;15:8813–8828. DOI:10.1021/acs.jpclett.4c01700。仅核实摘要及元数据。
Duignan TT. The Potential of Neural Network Potentials. ACS Phys Chem Au. 2024;4:232–241. DOI:10.1021/acsphyschemau.4c00004。已实际查看其图文摘要，仅借鉴方法间关系的图形表达，不复制原图。
其他方法清单主要按用户原稿整理，不声称本轮独立重新核实全部原稿参考文献。

## GenAI声明草案
During the preparation of this work, ChatGPT (OpenAI) was used to assist in organizing and designing the graphical abstract, drafting its caption and explanatory material, and generating code for editable vector artwork. An OpenAI image-generation tool was used for an earlier visual draft.
作者实际完成审核后才可补充：After using these tools, the authors reviewed and edited the content as needed and take full responsibility for the content of the publication. 应补充论文其他部分实际的GenAI使用情况。