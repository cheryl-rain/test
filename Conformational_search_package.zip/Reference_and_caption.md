## 绘图含义
横、纵坐标φ1和φ2代表抽象扭转自由度；等高线表示概念势能面。紫色虚线表示局限于单个势阱附近的局部采样，青绿色曲线表示跨多个区域的探索，金色M1、M2、M3表示候选极小值。路径与势能面均自行定义，只表达覆盖构象空间的概念，不对应任何具体分子，不是实测或实际模拟数据。不能把某条示意路径当作某个算法性能的量化结果。

## 主要视觉参考
Higo J, Ikebe J, Kamiya N, Nakamura H. Enhanced and effective conformational sampling of protein molecular systems for their free energy landscapes. Biophysical Reviews. 2012;4:27–44. DOI:10.1007/s12551-011-0063-6. https://doi.org/10.1007/s12551-011-0063-6
已实际查看该综述图2和图8：前者用能量面和轨迹讨论采样差异，后者用二维构象空间及多条轨迹说明不同区域的覆盖。本图借鉴这些科学表达惯例，但自行构造三势阱函数、采样路径及布局，没有复制原图像素、轮廓或轨迹。引用是设计和概念来源，不代表作者文献报告了本图数据。

## 补充方法图参考
Okamoto Y. Protein structure predictions by enhanced conformational sampling methods. Biophysics and Physicobiology. 2019;16:344–366. DOI:10.2142/biophysico.16.0_344. https://doi.org/10.2142/biophysico.16.0_344
已核实全文及图注：图1为遗传算法等方法流程图，图6为具体体系二维自由能面；未实际查看原图，不作为本图具体轮廓或布局依据。注意本图为势能面示意，并未把势能和自由能混称。

## 英文图注
Schematic illustration of conformational-space exploration on a torsional potential-energy landscape. Restricted local sampling remains within one basin, whereas broader exploration visits multiple basins and identifies candidate low-energy minima. The landscape and trajectories are conceptual illustrations and do not represent a specific molecule or simulation dataset.

## 中文图注
扭转势能面上的构象空间探索示意。局部采样局限于单个势阱附近，跨区域探索覆盖多个势阱，并识别候选低能极小值。图中势能面和路径均为概念示意，不对应具体分子或模拟数据。

## 如何编辑
Conformational_search.svg为文字可编辑的SVG：标题、坐标和图例保留为<text>节点，可在Inkscape/Illustrator使用文字工具编辑。PowerPoint请使用Conformational_search.pptx，含85个原生对象，曲线可编辑顶点。outlined.svg为文字转轮廓的矢量版，仅适合避免字体替换，不按文字编辑。PNG2800×2000为高分辨率导出，TIFF为无损LZW版本，PDF为矢量预览。单独局部图不采用整个图文摘要的55:28画布比例，整合时保留纵横比例，避免横向拉伸。

## GenAI说明
本图由ChatGPT辅助设计、编写绘图代码并输出可编辑矢量。沿用论文图文摘要的真实GenAI使用披露，作者完成审核后再确认内容。未使用AI生成实验数据。