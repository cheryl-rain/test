from pathlib import Path
import math,json,zipfile
from xml.sax.saxutils import escape
import numpy as np
from pptx import Presentation
from pptx.util import Inches,Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN
from pptx.enum.dml import MSO_LINE_DASH_STYLE
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from fontTools.ttLib import TTFont as FT
import fitz
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
O=Path(__file__).resolve().parent;W,H=1400,1000
N='#17364E';T='#07867F';P='#80529D';G='#B98426';GRAY='#647585';BORDER='#C9D5DE';RED='#D74646'
regular='/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf';bold='/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf';cmap=FT(regular).getBestCmap();scene=[]
def rect(x,y,w,h,fill='white',stroke=None,r=12,name='panel'):scene.append(dict(kind='rect',x=x,y=y,w=w,h=h,fill=fill,stroke=stroke,r=r,name=name))
def ell(x,y,r,fill,name='atom'):scene.append(dict(kind='ellipse',x=x-r,y=y-r,w=r*2,h=r*2,fill=fill,name=name))
def text(x,y,t,size=28,col=N,bold=False,align='start',name='text'):
 assert size>=24
 scene.append(dict(kind='text',x=x,y=y,t=t,size=size,col=col,bold=bold,align=align,font='DejaVu Sans' if any(ord(ch) not in cmap for ch in t) else 'Arial',name=name))
def poly(pts,fill=None,col=N,width=2,closed=False,dash=False,name='path'):scene.append(dict(kind='path',pts=[tuple(map(float,p)) for p in pts],col=col,width=width,dash=dash,fill=fill,closed=closed,name=name))
def line(x1,y1,x2,y2,col=N,width=2,dash=False,name='line'):poly([(x1,y1),(x2,y2)],col=col,width=width,dash=dash,name=name)
def arrow(x1,y1,x2,y2,col=N,width=3,head=10,dash=False,name='arrow'):
 dx=x2-x1;dy=y2-y1;l=math.hypot(dx,dy);ux,uy=dx/l,dy/l;bx,by=x2-ux*head,y2-uy*head;line(x1,y1,bx,by,col,width,dash,name+'_shaft');poly([(x2,y2),(bx-uy*head*.58,by+ux*head*.58),(bx+uy*head*.58,by-ux*head*.58)],col,col,0,True,name=name+'_head')
text(700,72,'Conformational search',48,N,True,'middle','title')
text(700,119,'Explore multiple basins on a torsional energy landscape',28,GRAY,False,'middle')
px,py,pw,ph=151,180,1080,590
# Analytic potential used only to draw an original conceptual contour surface.
xx=np.linspace(-3.2,3.2,180);yy=np.linspace(-3.2,3.2,150);X,Y=np.meshgrid(xx,yy)
Z=.035*(X*X+Y*Y)-2.5*np.exp(-((X+1.3)**2/.95+(Y+.95)**2/1.15))-2.1*np.exp(-((X-1.1)**2/.92+(Y-1.25)**2/.9))-1.85*np.exp(-((X-1.55)**2/.72+(Y+1.4)**2/.7))
def pos(u,v):return (px+(u+3.2)/6.4*pw,py+(3.2-v)/6.4*ph)
# Pale filled zones and line contours retain the visual distinction between potential and trajectory.
fig,ax=plt.subplots();levs=[-2.4,-1.9,-1.5,-1.1,-.7,-.35,-.1,.15]
cf=ax.contourf(X,Y,Z,levels=[-3]+levs+[1]);fills=['#C6DCD9','#D0E2DF','#D9E8E5','#E0ECEA','#E6EFED','#EDF3F1','#F3F6F5','#F8FAF9','#FBFCFC']
for k,segs in enumerate(cf.allsegs):
 for seg in segs:
  if len(seg)>2:poly([pos(u,v) for u,v in seg],fill=fills[min(k,len(fills)-1)],col=None,width=0,closed=True,name='energy_region')
ct=ax.contour(X,Y,Z,levels=levs)
for k,segs in enumerate(ct.allsegs):
 for seg in segs:poly([pos(u,v) for u,v in seg],col='#9CB7B4',width=1.4,name='energy_contour')
plt.close(fig)
line(px,py,px,py+ph,GRAY,1.8);line(px,py+ph,px+pw,py+ph,GRAY,1.8)
arrow(px,py+ph,px+pw+17,py+ph,GRAY,1.8,9);arrow(px,py+ph,px,py-15,GRAY,1.8,9)
text(px+pw/2,py+ph+46,'φ₁',34,GRAY,False,'middle','torsion1');text(px-51,py+ph/2,'φ₂',34,GRAY,False,'middle','torsion2')
# Smooth original illustrative trajectories using Catmull-Rom interpolation.
def smooth(points,n=20):
 p=[points[0]]+points+[points[-1]];result=[]
 for i in range(1,len(p)-2):
  a,b,c,d=[np.array(v,dtype=float) for v in p[i-1:i+3]]
  for t in np.linspace(0,1,n,endpoint=False):result.append(tuple(.5*((2*b)+(-a+c)*t+(2*a-5*b+4*c-d)*t*t+(-a+3*b-3*c+d)*t*t*t)))
 result.append(points[-1]);return result
local=[(-1.75,-1.25),(-1.1,-1.45),(-.85,-.85),(-1.45,-.45),(-1.85,-.9),(-1.1,-1.15),(-1.3,-.7),(-1.6,-1.0),(-1.35,-1.2)]
poly([pos(*p) for p in smooth(local)],col=P,width=4,dash=True,name='restricted_local_sampling')
broad=[(-2.45,-1.8),(-2.2,-.4),(-1.2,-.2),(-.7,-1.1),(-1.6,-1.8),(-1.9,-.9),(-.5,.15),(.1,1.85),(1.2,1.75),(1.65,.9),(.85,.65),(.45,1.4),(1.15,1.1),(2.2,.35),(2.3,-1.2),(1.25,-1.8),(.95,-1.0),(1.8,-.85),(1.8,-1.55),(1.5,-1.4)]
bp=smooth(broad);poly([pos(*p) for p in bp],col=T,width=4.1,name='cross_basin_exploration')
for j in [33,139,276]:arrow(*pos(*bp[j]),*pos(*bp[j+4]),T,3,12,name='exploration_direction')
# Candidate minima are symbols for regions, not molecule-specific conformer coordinates.
for label,u,v,dx,dy in [('M₁',-1.3,-.95,-42,45),('M₂',1.1,1.25,18,-18),('M₃',1.55,-1.4,20,45)]:
 x,y=pos(u,v);ell(x,y,12,'white','minimum_halo');ell(x,y,8,G,'candidate_minimum');text(x+dx,y+dy,label,29,N,True,name='minimum_label')
# One compact explanatory legend, no algorithm performance claim.
line(152,861,210,861,P,4,True);text(228,870,'Local sampling',27,P)
line(540,861,598,861,T,4);text(616,870,'Cross-basin exploration',27,T)
ell(1086,861,8,G);text(1105,870,'Minima',27,N)
rect(151,905,1080,52,'#E4EFED',None,12,'takeaway');text(691,941,'Broader coverage → candidate low-energy minima',28,N,True,'middle')
text(700,984,'Schematic landscape and paths; no specific molecule or simulation data.',24,GRAY,False,'middle','disclaimer')
# Export all formats from the SAME scene graph.
pdfmetrics.registerFont(TTFont('ArialGA','/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf'));pdfmetrics.registerFont(TTFont('ArialGABold','/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf'))
pdfmetrics.registerFont(TTFont('DejaVuGA','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'));pdfmetrics.registerFont(TTFont('DejaVuGABold','/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'))
c=canvas.Canvas(str(O/'Conformational_search_preview.pdf'),pagesize=(W,H));c.setFillColor('white');c.rect(0,0,W,H,fill=1,stroke=0)
parts=[f'<svg xmlns="http://www.w3.org/2000/svg" width="2800" height="2000" viewBox="0 0 {W} {H}"><title>Editable ensemble-centered ECD/VCD graphical abstract</title><desc>Original molecule-independent conceptual vector diagram. All landscapes and spectra are schematic; no molecular structures or embedded raster images.</desc><rect width="1400" height="1000" fill="white"/>']
r=Presentation();r.slide_width=Inches(W/100);r.slide_height=Inches(H/100);s=r.slides.add_slide(r.slide_layouts[6]);s.background.fill.solid();s.background.fill.fore_color.rgb=RGBColor(255,255,255)

def fillline(sh,fill=None,col=None,width=1.5,dash=False):
 if fill:sh.fill.solid();sh.fill.fore_color.rgb=RGBColor.from_string('FFFFFF' if fill=='white' else fill.lstrip('#'))
 else:sh.fill.background()
 if col:sh.line.color.rgb=RGBColor.from_string(col.lstrip('#'));sh.line.width=Pt(width*.72)
 else:sh.line.fill.background()
 if dash:sh.line.dash_style=MSO_LINE_DASH_STYLE.DASH
for i,a in enumerate(scene):
 kind=a['kind'];name=f'{i:03d}_'+a['name']
 if kind in ['rect','ellipse']:
  x,y,ww,hh=a['x'],a['y'],a['w'],a['h'];fil=a['fill'];stroke=a.get('stroke');typ=MSO_SHAPE.OVAL if kind=='ellipse' else MSO_SHAPE.ROUNDED_RECTANGLE if a['r'] else MSO_SHAPE.RECTANGLE
  sh=s.shapes.add_shape(typ,Inches(x/100),Inches(y/100),Inches(ww/100),Inches(hh/100));fillline(sh,fil,stroke);sh.name=name
  if kind=='rect':
   if a['r']:sh.adjustments[0]=min(.5,a['r']/min(ww,hh))
   parts.append(f'<rect id="{name}" x="{x}" y="{y}" width="{ww}" height="{hh}" rx="{a["r"]}" fill="{fil}" stroke="{stroke or "none"}" stroke-width="1.5"/>');c.setFillColor(fil);c.setStrokeColor(stroke or fil);c.roundRect(x,H-y-hh,ww,hh,a['r'],stroke=bool(stroke),fill=1)
  else:
   parts.append(f'<ellipse id="{name}" cx="{x+ww/2}" cy="{y+hh/2}" rx="{ww/2}" ry="{hh/2}" fill="{fil}"/>');c.setFillColor(fil);c.ellipse(x,H-y-hh,x+ww,H-y,stroke=0,fill=1)
 elif kind=='text':
  x,y,txt,size=a['x'],a['y'],a['t'],a['size'];fn=('DejaVuGA' if a['font']=='DejaVu Sans' else 'ArialGA')+('Bold' if a['bold'] else '');tw=pdfmetrics.stringWidth(txt,fn,size);align=a['align'];left=x-tw/2-3 if align=='middle' else x-tw-3 if align=='end' else x-2
  # Deliberately size each text box to its content so only the target label is selected.
  sh=s.shapes.add_textbox(Inches(left/100),Inches((y-size*.93)/100),Inches((tw+8)/100),Inches(size*1.35/100));sh.name=name;tf=sh.text_frame;tf.margin_left=tf.margin_right=tf.margin_top=tf.margin_bottom=0;tf.word_wrap=False
  pp=tf.paragraphs[0];pp.text=txt;pp.font.name=a['font'];pp.font.size=Pt(size*.72);pp.font.bold=a['bold'];pp.font.color.rgb=RGBColor.from_string('FFFFFF' if a['col']=='white' else a['col'].lstrip('#'));pp.space_after=Pt(0);pp.line_spacing=1
  pp.alignment=PP_ALIGN.CENTER if align=='middle' else PP_ALIGN.RIGHT if align=='end' else PP_ALIGN.LEFT
  parts.append(f'<text id="{name}" x="{x}" y="{y}" fill="{a["col"]}" font-family="{a["font"]},sans-serif" font-size="{size}" font-weight="{700 if a["bold"] else 400}" text-anchor="{align}">{escape(txt)}</text>');c.setFillColor(a['col']);c.setFont(fn,size);{'start':c.drawString,'middle':c.drawCentredString,'end':c.drawRightString}[align](x,H-y,txt)
 else:
  pts=a['pts'];path='M '+' L '.join(f'{x:.3f},{y:.3f}' for x,y in pts)+(' Z' if a['closed'] else '');parts.append(f'<path id="{name}" d="{path}" fill="{a["fill"] or "none"}" stroke="{a["col"] or "none"}" stroke-width="{a["width"]}"'+(' stroke-dasharray="7 5"' if a['dash'] else '')+'/>')
  p=c.beginPath();p.moveTo(pts[0][0],H-pts[0][1]);[p.lineTo(x,H-y) for x,y in pts[1:]]
  if a['closed']:p.close()
  c.setFillColor(a['fill'] or 'white');c.setStrokeColor(a['col'] or 'white');c.setLineWidth(a['width']);c.setDash([7,5] if a['dash'] else []);c.drawPath(p,fill=bool(a['fill']),stroke=bool(a['col']) and a['width']>0);c.setDash([])
  builder=s.shapes.build_freeform(pts[0][0],pts[0][1],scale=9144);builder.add_line_segments(pts[1:],close=a['closed']);sh=builder.convert_to_shape();sh.name=name;fillline(sh,a['fill'],a['col'] if a['width'] else None,a['width'],a['dash'])
c.showPage();c.save();parts.append('</svg>');(O/'Conformational_search.svg').write_text('\n'.join(parts));(O/'editable_scene.json').write_text(json.dumps(scene,ensure_ascii=False,indent=2))
s.notes_slide.notes_text_frame.text='Original schematic conformational-search illustration inspired by common scientific conventions in Higo et al., Biophysical Reviews2012, DOI10.1007/s12551-011-0063-6, Figures2 and8. Both source figures were viewed. Source figure pixels and paths were not copied. The original two-dimensional analytic torsional potential, sampling paths and candidate minima are conceptual; no molecule, numerical energies or measured trajectories are represented. Local sampling and cross-basin exploration illustrate coverage of conformational space, not a measured comparison of algorithms. All native PPT shapes and text editable; text SVG retains text nodes. AI-assisted drawing and code.'
from pptx.oxml.xmlchemy import OxmlElement
for obj in s.shapes:
 for ef in obj._element.xpath('.//a:effectRef'):ef.set('idx','0')
 sppr=obj._element.find('{http://schemas.openxmlformats.org/presentationml/2006/main}spPr')
 if sppr is not None:sppr.append(OxmlElement('a:effectLst'))
r.save(O/'Conformational_search.pptx')
pdf=fitz.open(O/'Conformational_search_preview.pdf');page=pdf[0];page.get_pixmap(matrix=fitz.Matrix(2,2),alpha=False).save(O/'Conformational_search_2800x2000.png');page.get_pixmap(matrix=fitz.Matrix(.5,.5),alpha=False).save(O/'Conformational_search_preview.png')

(O/'Conformational_search_outlined.svg').write_text(page.get_svg_image(text_as_path=True))
print('Exported',len(s.shapes),'editable objects')
