## 设计与文章逻辑
按照“构象搜索→几何优化与频率→能量和布居→ECD/VCD性质计算→谱线模拟与实验比较”组织。突出构象采样和布居，底部用溶剂模型、动态集合、大体系及AI辅助方法回应文章后半部分。ECD与VCD为并行计算分支。全部图形重新绘制，没有复制文献图片。

## 具体改进
用具有真实连接关系和S构型的香茅醛三维构象取代装饰性分子图；以双扭转角势能面展示采样；以质量加权Hessian特征方程和局部势阱说明频率检验；将最低能量对应最大Boltzmann布居；分别画电子跃迁和振动旋光强度棒谱。GA在底部指遗传算法，ML指机器学习。

## 科学含义及使用边界
分子图来自RDKit ETKDG/MMFF构象生成，仅用于结构展示，并非本文新完成的DFT计算。示例为(S)-citronellal，SMILES：CC(C)=CCC[C@H](C)CC=O；省略多数氢原子，星号标记手性中心。势能面、能级、布居条、振动箭头及谱线均为概念示意，不是该分子的量化计算或实验结果。Calc./Exp.表示比较流程，不代表实际数据。H为质量加权Hessian；HFF为谐振力场，APT/AAT分别为原子极性/轴性张量。实际最小值检验需排除平移转动零模。ΔG权重为示例；ΔE、ΔH、ΔG和低频处理须与具体模型一致；MD权重需充分采样，不应默认等价于静态谐振热力学校正。图示布居为物理关系示意，不与展示的MMFF构象能量作定量对应。

## 参考文献 [1]
[1] Li XC, Ferreira D, Ding Y. Determination of Absolute Configuration of Natural Products: Theoretical Calculation of Electronic Circular Dichroism as a Tool. Curr Org Chem. 2010;14:1678-1697. DOI: 10.2174/138527210792927717. https://doi.org/10.2174/138527210792927717
对应内容：主流程第1、4、5栏：全文Computational Methods；图16图注的势能面、图21的旋光强度棒谱和展宽谱、图37的布居加权谱与实验比较。借鉴图形表达惯例，未复制图或使用原始谱数据。
访问层级：已阅读可访问全文及相关图注；未获取出版商原图，不声称已目视查看原图。

## 参考文献 [2]
[2] Pracht P, Bohle F, Grimme S. Automated exploration of the low-energy chemical space with fast quantum chemical methods. Phys Chem Chem Phys. 2020;22:7169-7192. DOI: 10.1039/c9cp06869d. https://doi.org/10.1039/c9cp06869d
对应内容：第1栏CREST与低能构象集合。方法论文，用于核实采样工具的角色。
访问层级：仅核实摘要和书目信息，未获取全文；不以该文特定图形作为直接重绘依据。

## 参考文献 [3]
[3] Pescitelli G, Di Bari L, Berova N. Conformational aspects in the studies of organic compounds by electronic circular dichroism. Chem Soc Rev. 2011;40:4603-4625. DOI: 10.1039/c1cs15036g. https://doi.org/10.1039/c1cs15036g
对应内容：整体核心信息：ECD应考虑整个构象集合，构象变化可影响谱线和符号。
访问层级：仅核实摘要和书目信息，未获取全文；不以该文特定图形作为直接重绘依据。

## 参考文献 [4]
[4] Pescitelli G, Bruhn T. Good Computational Practice in the Assignment of Absolute Configurations by TDDFT Calculations of ECD Spectra. Chirality. 2016;28:466-474. DOI: 10.1002/chir.22600. https://doi.org/10.1002/chir.22600
对应内容：第2—5栏及验证要求：避免将TDDFT-ECD作为黑箱，以计算选择和实验比较共同支持构型判断。
访问层级：仅核实摘要和书目信息，未获取全文；不以该文特定图形作为直接重绘依据。

## 参考文献 [5]
[5] Bloino J, Jähnigen S, Merten C. After 50 Years of Vibrational Circular Dichroism Spectroscopy: Challenges and Opportunities of Increasingly Accurate and Complex Experiments and Computations. J Phys Chem Lett. 2024;15:8813-8828. DOI: 10.1021/acs.jpclett.4c01700. https://doi.org/10.1021/acs.jpclett.4c01700
对应内容：第4栏VCD及底部动态/环境方法：静态与动态计算、复杂体系和精度问题。
访问层级：仅核实摘要和书目信息，未获取全文；不以该文特定图形作为直接重绘依据。

## 参考文献 [6]
[6] Koenis MAJ, Xia Y, Domingos SR, Visscher L, Buma WJ, Nicu VP. Taming conformational heterogeneity in and with vibrational circular dichroism spectroscopy. Chem Sci. 2019;10:7680-7689. DOI: 10.1039/c9sc02866h. https://doi.org/10.1039/c9sc02866h
对应内容：第3和第5栏、底部GA布居：全文及图1—3、图7图注，分别涉及柔性分子、布居变化、VCD比较及交叉验证。属于原始研究，不是综述。
访问层级：已阅读可访问全文及相关图注；未获取出版商原图，不声称已目视查看原图。

## 编辑与格式
PPTX中所有文字、分子原子/化学键、曲线、箭头和面板均为原生对象，可用“选择窗格”定位。SVG文本版保留可编辑文字；outlined.svg为文字转轮廓的纯矢量版，适合避免字体替换，但文字不再作为文本编辑。两者均无嵌入位图。PNG为4400×2240；另有1100×560最小尺寸预览；比例均为55:28。PDF用于预览。PPTX采用同一场景导出，字体排版在不同软件上可能略有差异。投稿优先使用PNG或转轮廓SVG，保留PPTX继续修改。

## 英文图注建议
An ensemble-centered quantum-chemical workflow links conformational sampling, geometry refinement and vibrational verification, conformer energy and population evaluation, and parallel ECD/VCD property calculations to simulated spectra and experimental comparison. Solvation, dynamics, multiscale models and AI-assisted methods support the workflow. Molecular geometries illustrate connectivity and stereochemistry; potential-energy surfaces, energy levels, populations and spectra are conceptual schematics, not newly reported calculations or measurements.

## GenAI声明草案
During the preparation of this work, ChatGPT (OpenAI) was used to assist in organizing and designing the graphical abstract, drafting its caption and explanatory material, and generating code for the editable vector artwork. An OpenAI image-generation tool was used for an earlier visual draft.
作者完成审核后才可补充：After using these tools, the authors reviewed and edited the content as needed and take full responsibility for the content of the publication. 应按实际情况补充论文其他部分的AI使用情况。